-- Adminer 4.3.1 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';

DROP TABLE IF EXISTS `ibf_announcements`;
CREATE TABLE `ibf_announcements` (
  `announce_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `announce_title` varchar(255) NOT NULL DEFAULT '',
  `announce_post` text NOT NULL,
  `announce_forum` text NOT NULL,
  `announce_member_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `announce_html_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `announce_views` int(10) unsigned NOT NULL DEFAULT 0,
  `announce_start` int(10) unsigned NOT NULL DEFAULT 0,
  `announce_end` int(10) unsigned NOT NULL DEFAULT 0,
  `announce_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`announce_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_attachments`;
CREATE TABLE `ibf_attachments` (
  `attach_id` int(10) NOT NULL AUTO_INCREMENT,
  `attach_ext` varchar(10) NOT NULL DEFAULT '',
  `attach_file` varchar(250) NOT NULL DEFAULT '',
  `attach_location` varchar(250) NOT NULL DEFAULT '',
  `attach_thumb_location` varchar(250) NOT NULL DEFAULT '',
  `attach_thumb_width` smallint(5) NOT NULL DEFAULT 0,
  `attach_thumb_height` smallint(5) NOT NULL DEFAULT 0,
  `attach_is_image` tinyint(1) NOT NULL DEFAULT 0,
  `attach_hits` int(10) NOT NULL DEFAULT 0,
  `attach_date` int(10) NOT NULL DEFAULT 0,
  `attach_temp` tinyint(1) NOT NULL DEFAULT 0,
  `attach_pid` int(10) NOT NULL DEFAULT 0,
  `attach_post_key` varchar(32) NOT NULL DEFAULT '0',
  `attach_msg` int(10) NOT NULL DEFAULT 0,
  `attach_member_id` mediumint(8) NOT NULL DEFAULT 0,
  `attach_approved` int(10) NOT NULL DEFAULT 1,
  `attach_filesize` int(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`attach_id`),
  KEY `attach_pid` (`attach_pid`),
  KEY `attach_msg` (`attach_msg`),
  KEY `attach_post_key` (`attach_post_key`),
  KEY `attach_mid_size` (`attach_member_id`,`attach_filesize`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_attachments_type`;
CREATE TABLE `ibf_attachments_type` (
  `atype_id` int(10) NOT NULL AUTO_INCREMENT,
  `atype_extension` varchar(18) NOT NULL DEFAULT '',
  `atype_mimetype` varchar(255) NOT NULL DEFAULT '',
  `atype_post` tinyint(1) NOT NULL DEFAULT 1,
  `atype_photo` tinyint(1) NOT NULL DEFAULT 0,
  `atype_img` text NOT NULL,
  PRIMARY KEY (`atype_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_cache_store`;
CREATE TABLE `ibf_cache_store` (
  `cs_key` varchar(255) NOT NULL DEFAULT '',
  `cs_value` mediumtext NOT NULL,
  `cs_extra` varchar(255) NOT NULL DEFAULT '',
  `cs_array` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`cs_key`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_category`;
CREATE TABLE `ibf_category` (
  `cid` smallint(4) NOT NULL AUTO_INCREMENT,
  `title` char(32) NOT NULL DEFAULT '',
  `parent` smallint(4) DEFAULT 0,
  `content` smallint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`cid`),
  KEY `name` (`title`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_conf_settings`;
CREATE TABLE `ibf_conf_settings` (
  `conf_id` int(10) NOT NULL AUTO_INCREMENT,
  `conf_title` varchar(255) NOT NULL DEFAULT '',
  `conf_description` text NOT NULL,
  `conf_group` varchar(255) NOT NULL DEFAULT '',
  `conf_type` varchar(255) NOT NULL DEFAULT '',
  `conf_key` varchar(255) NOT NULL DEFAULT '',
  `conf_value` text NOT NULL,
  `conf_default` text NOT NULL,
  `conf_extra` text NOT NULL,
  `conf_evalphp` text NOT NULL,
  `conf_protected` tinyint(1) NOT NULL DEFAULT 0,
  `conf_position` smallint(3) NOT NULL DEFAULT 0,
  `conf_start_group` varchar(255) NOT NULL DEFAULT '',
  `conf_end_group` tinyint(1) NOT NULL DEFAULT 0,
  `conf_help_key` varchar(255) NOT NULL DEFAULT '0',
  `conf_add_cache` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`conf_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_conf_settings_titles`;
CREATE TABLE `ibf_conf_settings_titles` (
  `conf_title_id` smallint(3) NOT NULL AUTO_INCREMENT,
  `conf_title_title` varchar(255) NOT NULL DEFAULT '',
  `conf_title_desc` text NOT NULL,
  `conf_title_count` smallint(3) NOT NULL DEFAULT 0,
  `conf_title_noshow` tinyint(1) NOT NULL DEFAULT 0,
  `conf_title_keyword` varchar(200) NOT NULL DEFAULT '0',
  PRIMARY KEY (`conf_title_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_content`;
CREATE TABLE `ibf_content` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL DEFAULT 0,
  `title` varchar(128) NOT NULL DEFAULT '',
  `author` varchar(32) NOT NULL DEFAULT '',
  `data` text NOT NULL,
  `num_votes` tinyint(4) NOT NULL DEFAULT 0,
  `total_votes` bigint(10) NOT NULL DEFAULT 0,
  `date` int(10) DEFAULT NULL,
  `views` bigint(10) NOT NULL DEFAULT 0,
  `rate` float NOT NULL DEFAULT 0,
  `n_comments` smallint(3) NOT NULL DEFAULT 0,
  `open` tinyint(1) NOT NULL DEFAULT 0,
  `mid` mediumint(8) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_content_cat`;
CREATE TABLE `ibf_content_cat` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `o` tinyint(4) NOT NULL DEFAULT 0,
  `title` varchar(128) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `number` mediumint(10) NOT NULL DEFAULT 0,
  `pview` varchar(255) DEFAULT NULL,
  `padd` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_content_settings`;
CREATE TABLE `ibf_content_settings` (
  `online` tinyint(1) NOT NULL DEFAULT 1,
  `contents` varchar(128) DEFAULT NULL,
  `contentp` varchar(128) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_custom_bbcode`;
CREATE TABLE `ibf_custom_bbcode` (
  `bbcode_id` int(10) NOT NULL AUTO_INCREMENT,
  `bbcode_title` varchar(255) NOT NULL DEFAULT '',
  `bbcode_desc` text NOT NULL,
  `bbcode_tag` varchar(255) NOT NULL DEFAULT '',
  `bbcode_replace` text NOT NULL,
  `bbcode_useoption` tinyint(1) NOT NULL DEFAULT 0,
  `bbcode_example` text NOT NULL,
  PRIMARY KEY (`bbcode_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_faq`;
CREATE TABLE `ibf_faq` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL DEFAULT '',
  `text` text DEFAULT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_faq_adv`;
CREATE TABLE `ibf_faq_adv` (
  `id` mediumint(2) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL DEFAULT '',
  `text` text NOT NULL,
  `description` text NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `updated` mediumint(16) DEFAULT NULL,
  `frominvis` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  FULLTEXT KEY `text` (`text`,`description`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_files`;
CREATE TABLE `ibf_files` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `cat` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `fname` varchar(70) NOT NULL DEFAULT '',
  `fdesc` text NOT NULL,
  `author` varchar(75) NOT NULL DEFAULT '',
  `poster` varchar(75) NOT NULL DEFAULT '',
  `mid` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `date` varchar(13) NOT NULL DEFAULT '',
  `updated` varchar(13) NOT NULL DEFAULT '',
  `views` smallint(5) unsigned NOT NULL DEFAULT 0,
  `downloads` smallint(6) NOT NULL DEFAULT 0,
  `topic` mediumint(8) NOT NULL DEFAULT 0,
  `open` tinyint(1) NOT NULL DEFAULT 0,
  `screenshot` varchar(250) NOT NULL DEFAULT '',
  `screenshot1` varchar(250) NOT NULL DEFAULT '',
  `votes` tinyint(4) NOT NULL DEFAULT 0,
  `total` tinyint(4) NOT NULL DEFAULT 0,
  `rating` tinyint(4) NOT NULL DEFAULT 0,
  `url` varchar(250) NOT NULL DEFAULT '',
  `link` varchar(250) NOT NULL DEFAULT '',
  `current` tinyint(1) NOT NULL DEFAULT 1,
  `ipaddress` varchar(32) NOT NULL DEFAULT '0',
  `is_broken` tinyint(1) NOT NULL DEFAULT 0,
  `mems_subs` text DEFAULT NULL,
  `ext` char(3) DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_files_cats`;
CREATE TABLE `ibf_files_cats` (
  `cid` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `sub` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `cname` varchar(50) NOT NULL DEFAULT '',
  `cdesc` tinytext NOT NULL,
  `copen` tinyint(1) unsigned NOT NULL DEFAULT 1,
  `dis_screen` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `dis_screen_cat` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `screen_req` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `authorize` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `fordaforum` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` tinyint(4) NOT NULL DEFAULT 0,
  `show_notes` tinyint(1) NOT NULL DEFAULT 0,
  `cnotes` tinytext NOT NULL,
  `group_perm` varchar(250) NOT NULL DEFAULT '*',
  `tot_files` mediumint(8) NOT NULL DEFAULT 0,
  `last_info` varchar(255) DEFAULT NULL,
  `type` tinyint(10) NOT NULL DEFAULT 0,
  UNIQUE KEY `id` (`cid`),
  KEY `position` (`position`),
  KEY `sub` (`sub`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_files_comments`;
CREATE TABLE `ibf_files_comments` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `file_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `mem_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `name` varchar(75) NOT NULL DEFAULT '',
  `date` varchar(13) NOT NULL DEFAULT '0',
  `comment` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_files_custentered`;
CREATE TABLE `ibf_files_custentered` (
  `file_id` mediumint(8) NOT NULL DEFAULT 0,
  PRIMARY KEY (`file_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_files_custfields`;
CREATE TABLE `ibf_files_custfields` (
  `fid` smallint(5) NOT NULL AUTO_INCREMENT,
  `ftitle` varchar(200) NOT NULL DEFAULT '',
  `fcontent` text DEFAULT NULL,
  `ftype` varchar(250) DEFAULT 'text',
  `freq` tinyint(1) NOT NULL DEFAULT 0,
  `fshow` tinyint(1) NOT NULL DEFAULT 0,
  `fmaxinput` smallint(6) DEFAULT 250,
  `ftopic` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`fid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_files_reviews`;
CREATE TABLE `ibf_files_reviews` (
  `review_id` int(4) NOT NULL AUTO_INCREMENT,
  `file_id` int(4) NOT NULL DEFAULT 0,
  `reviewer` varchar(32) NOT NULL DEFAULT '',
  `thoughts` text NOT NULL,
  `creativity` decimal(2,1) NOT NULL DEFAULT 0.0,
  `terrain` decimal(2,1) NOT NULL DEFAULT 0.0,
  `orginality` decimal(2,1) NOT NULL DEFAULT 0.0,
  `complexity` decimal(2,1) NOT NULL DEFAULT 0.0,
  `fun` decimal(2,1) NOT NULL DEFAULT 0.0,
  `overall` decimal(2,1) NOT NULL DEFAULT 0.0,
  `finished` char(3) NOT NULL DEFAULT 'No',
  PRIMARY KEY (`review_id`),
  FULLTEXT KEY `thoughts` (`thoughts`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_files_reviews_req`;
CREATE TABLE `ibf_files_reviews_req` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `file_id` int(4) NOT NULL DEFAULT 0,
  `status` tinyint(2) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_files_votes`;
CREATE TABLE `ibf_files_votes` (
  `mid` mediumint(8) NOT NULL DEFAULT 0,
  `rating` tinyint(1) NOT NULL DEFAULT 0,
  `did` mediumint(8) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_forums`;
CREATE TABLE `ibf_forums` (
  `id` smallint(5) NOT NULL DEFAULT 0,
  `topics` mediumint(6) DEFAULT 0,
  `posts` mediumint(6) DEFAULT 0,
  `last_post` int(10) DEFAULT NULL,
  `last_poster_id` mediumint(8) NOT NULL DEFAULT 0,
  `last_poster_name` varchar(32) DEFAULT NULL,
  `name` varchar(128) NOT NULL DEFAULT '',
  `description` text DEFAULT NULL,
  `position` tinyint(2) DEFAULT NULL,
  `use_ibc` tinyint(1) DEFAULT NULL,
  `use_html` tinyint(1) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `last_title` varchar(128) DEFAULT NULL,
  `last_id` int(10) DEFAULT NULL,
  `sort_key` varchar(32) DEFAULT NULL,
  `sort_order` varchar(32) DEFAULT NULL,
  `prune` tinyint(3) DEFAULT NULL,
  `show_rules` tinyint(1) DEFAULT NULL,
  `preview_posts` tinyint(1) DEFAULT NULL,
  `allow_poll` tinyint(1) NOT NULL DEFAULT 1,
  `allow_pollbump` tinyint(1) NOT NULL DEFAULT 0,
  `inc_postcount` tinyint(1) NOT NULL DEFAULT 1,
  `skin_id` int(10) DEFAULT NULL,
  `parent_id` mediumint(5) DEFAULT -1,
  `sub_can_post` tinyint(1) DEFAULT 1,
  `quick_reply` tinyint(1) DEFAULT 0,
  `redirect_url` varchar(250) DEFAULT '',
  `redirect_on` tinyint(1) NOT NULL DEFAULT 0,
  `redirect_hits` int(10) NOT NULL DEFAULT 0,
  `redirect_loc` varchar(250) DEFAULT '',
  `rules_title` varchar(255) NOT NULL DEFAULT '',
  `rules_text` text NOT NULL,
  `topic_mm_id` varchar(250) NOT NULL DEFAULT '',
  `notify_modq_emails` text DEFAULT NULL,
  `permission_custom_error` text NOT NULL,
  `permission_array` mediumtext NOT NULL,
  `permission_showtopic` tinyint(1) NOT NULL DEFAULT 0,
  `queued_topics` mediumint(6) NOT NULL DEFAULT 0,
  `queued_posts` mediumint(6) NOT NULL DEFAULT 0,
  `icon` text NOT NULL,
  `start` text DEFAULT NULL,
  `activity` tinyint(2) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `position` (`position`,`parent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_forumscounter`;
CREATE TABLE `ibf_forumscounter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page` varchar(50) NOT NULL DEFAULT '',
  `hits` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_forum_perms`;
CREATE TABLE `ibf_forum_perms` (
  `perm_id` int(10) NOT NULL AUTO_INCREMENT,
  `perm_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`perm_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_forum_tracker`;
CREATE TABLE `ibf_forum_tracker` (
  `frid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `member_id` varchar(32) NOT NULL DEFAULT '',
  `forum_id` smallint(5) NOT NULL DEFAULT 0,
  `start_date` int(10) DEFAULT NULL,
  `last_sent` int(10) NOT NULL DEFAULT 0,
  `forum_track_type` varchar(100) NOT NULL DEFAULT 'delayed',
  PRIMARY KEY (`frid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_groups`;
CREATE TABLE `ibf_groups` (
  `g_id` int(3) unsigned NOT NULL AUTO_INCREMENT,
  `g_view_board` tinyint(1) DEFAULT NULL,
  `g_mem_info` tinyint(1) DEFAULT NULL,
  `g_other_topics` tinyint(1) DEFAULT NULL,
  `g_use_search` tinyint(1) DEFAULT NULL,
  `g_email_friend` tinyint(1) DEFAULT NULL,
  `g_invite_friend` tinyint(1) DEFAULT NULL,
  `g_edit_profile` tinyint(1) DEFAULT NULL,
  `g_post_new_topics` tinyint(1) DEFAULT NULL,
  `g_reply_own_topics` tinyint(1) DEFAULT NULL,
  `g_reply_other_topics` tinyint(1) DEFAULT NULL,
  `g_edit_posts` tinyint(1) DEFAULT NULL,
  `g_delete_own_posts` tinyint(1) DEFAULT NULL,
  `g_open_close_posts` tinyint(1) DEFAULT NULL,
  `g_delete_own_topics` tinyint(1) DEFAULT NULL,
  `g_post_polls` tinyint(1) DEFAULT NULL,
  `g_vote_polls` tinyint(1) DEFAULT NULL,
  `g_use_pm` tinyint(1) DEFAULT NULL,
  `g_is_supmod` tinyint(1) DEFAULT NULL,
  `g_access_cp` tinyint(1) DEFAULT NULL,
  `g_title` varchar(32) NOT NULL DEFAULT '',
  `g_can_remove` tinyint(1) DEFAULT NULL,
  `g_append_edit` tinyint(1) DEFAULT NULL,
  `g_access_offline` tinyint(1) DEFAULT NULL,
  `g_avoid_q` tinyint(1) DEFAULT NULL,
  `g_avoid_flood` tinyint(1) DEFAULT NULL,
  `g_icon` text NOT NULL,
  `g_attach_max` bigint(20) DEFAULT NULL,
  `g_avatar_upload` tinyint(1) DEFAULT 0,
  `g_calendar_post` tinyint(1) DEFAULT 0,
  `g_d_add_files` tinyint(1) DEFAULT NULL,
  `g_d_ibcode_files` tinyint(1) DEFAULT NULL,
  `g_d_html_files` tinyint(1) DEFAULT NULL,
  `g_do_download` tinyint(1) DEFAULT NULL,
  `g_d_edit_files` tinyint(1) DEFAULT NULL,
  `g_d_delete_files` tinyint(1) DEFAULT 0,
  `g_d_manage_files` tinyint(1) DEFAULT NULL,
  `g_d_allow_dl_offline` tinyint(1) DEFAULT NULL,
  `g_d_post_comments` tinyint(1) DEFAULT 0,
  `g_d_approve_down` tinyint(1) DEFAULT 0,
  `g_d_eofs` tinyint(1) DEFAULT 0,
  `g_d_optimize_db` tinyint(1) DEFAULT 0,
  `g_d_check_links` tinyint(1) DEFAULT 0,
  `g_d_check_topics` tinyint(1) DEFAULT 0,
  `g_d_max_dls` tinyint(4) DEFAULT 0,
  `g_d_manage_coms` tinyint(1) DEFAULT 0,
  `prefix` varchar(250) DEFAULT NULL,
  `suffix` varchar(250) DEFAULT NULL,
  `g_max_messages` int(5) DEFAULT 50,
  `g_max_mass_pm` int(5) DEFAULT 0,
  `g_search_flood` mediumint(6) DEFAULT 20,
  `g_edit_cutoff` int(10) DEFAULT 0,
  `g_promotion` varchar(10) DEFAULT '-1&-1',
  `g_post_closed` tinyint(1) DEFAULT 0,
  `g_perm_id` varchar(255) NOT NULL DEFAULT '',
  `g_photo_max_vars` varchar(200) DEFAULT '',
  `g_dohtml` tinyint(1) NOT NULL DEFAULT 0,
  `g_edit_topic` tinyint(1) NOT NULL DEFAULT 0,
  `g_email_limit` varchar(15) NOT NULL DEFAULT '10:15',
  `mod_wwo_g_online_info` tinyint(1) NOT NULL DEFAULT 0,
  `g_view_affiliate` tinyint(1) NOT NULL DEFAULT 1,
  `g_ad_boxes` varchar(255) NOT NULL DEFAULT 'ALL',
  `g_rate_members` tinyint(1) DEFAULT 1,
  `g_display` tinyint(3) NOT NULL DEFAULT 100,
  `g_fine_edit` tinyint(1) NOT NULL DEFAULT 0,
  `g_allow_inventoryedit` tinyint(1) NOT NULL DEFAULT 0,
  `g_discount` int(3) NOT NULL DEFAULT 0,
  `g_bypass_badwords` tinyint(1) NOT NULL DEFAULT 0,
  `g_can_msg_attach` tinyint(1) NOT NULL DEFAULT 0,
  `g_attach_per_post` int(10) NOT NULL DEFAULT 0,
  `g_access_store` tinyint(1) NOT NULL DEFAULT 1,
  `g_donate_points` tinyint(1) NOT NULL DEFAULT 1,
  `g_donate_items` tinyint(1) NOT NULL DEFAULT 1,
  `g_buyitems` tinyint(1) NOT NULL DEFAULT 1,
  `g_gain_points` tinyint(1) NOT NULL DEFAULT 1,
  `g_l_add_links` tinyint(1) NOT NULL DEFAULT 0,
  `g_l_mod_links` tinyint(1) NOT NULL DEFAULT 0,
  `g_l_add_comments` tinyint(1) NOT NULL DEFAULT 0,
  `g_l_access_close` tinyint(1) NOT NULL DEFAULT 0,
  `g_l_rate_links` tinyint(1) NOT NULL DEFAULT 0,
  `g_l_report_links` tinyint(1) NOT NULL DEFAULT 0,
  `g_hide_in_list` tinyint(1) NOT NULL DEFAULT 0,
  `g_hide_from_list` tinyint(1) NOT NULL DEFAULT 0,
  `g_view_dshoutbox` tinyint(1) DEFAULT 1,
  `g_post_dshoutbox` tinyint(1) DEFAULT 1,
  `g_dshoutbox_mod` tinyint(1) DEFAULT 0,
  `g_dshout_limit` int(11) DEFAULT 0,
  `g_dshouts_today` varchar(100) DEFAULT '0',
  `g_dshout_flood` int(11) DEFAULT NULL,
  `g_dshout_bypass` tinyint(1) DEFAULT 0,
  `g_dshout_saveload` tinyint(1) DEFAULT 1,
  `g_dshout_bwbypass` tinyint(1) DEFAULT 0,
  `g_dshout_editown` tinyint(1) DEFAULT 1,
  `g_dshout_deleteown` tinyint(1) DEFAULT 0,
  `arcade_access` tinyint(1) NOT NULL DEFAULT 1,
  `p_require` mediumint(8) NOT NULL DEFAULT 0,
  `max_play` mediumint(8) NOT NULL DEFAULT 0,
  `ppd_require` mediumint(8) NOT NULL DEFAULT 0,
  `g_mydir_access` tinyint(1) DEFAULT 1,
  `g_mydir_chmod` tinyint(1) DEFAULT 1,
  `g_mydir_download` tinyint(1) DEFAULT 1,
  `g_mydir_rename` tinyint(1) DEFAULT 1,
  `g_mydir_logactions` tinyint(1) DEFAULT 1,
  `g_mydir_maxdirsize` varchar(20) DEFAULT '{def}',
  `g_mydir_maxuploadsize` varchar(20) DEFAULT '{def}',
  `g_mydir_subdirs` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`g_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_links`;
CREATE TABLE `ibf_links` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `cat` mediumint(8) NOT NULL DEFAULT 0,
  `link` varchar(75) NOT NULL DEFAULT '0',
  `href` varchar(255) NOT NULL DEFAULT '',
  `date` varchar(13) NOT NULL DEFAULT '0',
  `ldesc` mediumtext DEFAULT NULL,
  `img` varchar(75) NOT NULL DEFAULT 'none.gif',
  `mem_id` mediumint(8) NOT NULL DEFAULT 0,
  `mem_name` varchar(75) NOT NULL DEFAULT 'Guest',
  `open` tinyint(1) NOT NULL DEFAULT 0,
  `hits` mediumint(8) NOT NULL DEFAULT 0,
  `rating` mediumint(8) NOT NULL DEFAULT 0,
  `is_affiliate` tinyint(1) NOT NULL DEFAULT 0,
  `hidden_by` mediumint(8) NOT NULL DEFAULT 0,
  `hidden_on` varchar(13) NOT NULL DEFAULT '0',
  `tot_comments` mediumint(8) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_links_cats`;
CREATE TABLE `ibf_links_cats` (
  `cid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `sub` mediumint(8) NOT NULL DEFAULT 0,
  `cname` varchar(75) NOT NULL DEFAULT '0',
  `desc` tinytext NOT NULL,
  `open` tinyint(1) NOT NULL DEFAULT 0,
  `show_notes` tinyint(1) NOT NULL DEFAULT 0,
  `cnotes` mediumtext NOT NULL,
  `last_link` varchar(85) NOT NULL DEFAULT '0',
  `tot_links` mediumint(8) NOT NULL DEFAULT 0,
  `tot_hits` mediumint(8) NOT NULL DEFAULT 0,
  `last_link_date` varchar(13) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_links_comments`;
CREATE TABLE `ibf_links_comments` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `link_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `mem_id` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `name` varchar(75) NOT NULL DEFAULT '',
  `date` varchar(13) NOT NULL DEFAULT '0',
  `comment` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_links_ratings`;
CREATE TABLE `ibf_links_ratings` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `date` varchar(13) NOT NULL DEFAULT '0',
  `mem_id` mediumint(8) NOT NULL DEFAULT 0,
  `link_id` mediumint(8) NOT NULL DEFAULT 0,
  `rate` tinyint(5) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `rate` (`rate`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_members`;
CREATE TABLE `ibf_members` (
  `id` mediumint(8) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL DEFAULT '',
  `mgroup` smallint(3) NOT NULL DEFAULT 0,
  `joined` int(10) NOT NULL DEFAULT 0,
  `posts` mediumint(7) DEFAULT 0,
  `title` varchar(64) DEFAULT NULL,
  `time_offset` varchar(10) DEFAULT NULL,
  `last_post` int(10) DEFAULT NULL,
  `restrict_post` varchar(100) NOT NULL DEFAULT '0',
  `shout_style` char(1) NOT NULL DEFAULT 'n',
  `new_msg` tinyint(2) DEFAULT NULL,
  `msg_total` smallint(5) DEFAULT 0,
  `show_popup` tinyint(1) DEFAULT NULL,
  `misc` varchar(128) DEFAULT NULL,
  `last_visit` int(10) DEFAULT 0,
  `last_activity` int(10) DEFAULT 0,
  `dst_in_use` tinyint(1) DEFAULT 0,
  `view_prefs` varchar(64) DEFAULT '-1&-1',
  `mod_posts` varchar(100) NOT NULL DEFAULT '0',
  `auto_track` varchar(50) DEFAULT '0',
  `org_perm_id` varchar(255) DEFAULT '',
  `org_supmod` tinyint(1) DEFAULT 0,
  `temp_ban` varchar(100) DEFAULT '0',
  `sub_end` int(10) NOT NULL DEFAULT 0,
  `files` smallint(5) DEFAULT 0,
  `downloads` smallint(5) DEFAULT 0,
  `name_prefix` text NOT NULL,
  `name_suffix` text NOT NULL,
  `login_anonymous` char(3) NOT NULL DEFAULT '0&0',
  `ignored_users` text NOT NULL,
  `mgroup_others` varchar(255) NOT NULL DEFAULT '',
  `member_login_key` varchar(32) NOT NULL DEFAULT '',
  `subs_pkg_chosen` smallint(3) NOT NULL DEFAULT 0,
  `links` mediumint(8) NOT NULL DEFAULT 0,
  `view_thx` tinyint(1) DEFAULT 1,
  `title_prefix` text NOT NULL,
  `title_suffix` text NOT NULL,
  `tickets` int(11) DEFAULT NULL,
  `use_dshoutbox` tinyint(1) DEFAULT 1,
  `dshoutbox_mod` tinyint(1) DEFAULT 0,
  `dshouts` mediumint(5) NOT NULL DEFAULT 0,
  `dshout_limit` int(11) DEFAULT 0,
  `dshouts_today` varchar(100) DEFAULT '0',
  `dshouts_alltime` int(11) NOT NULL DEFAULT 0,
  `dshout_saveload` tinyint(1) DEFAULT 1,
  `dshout_bwbypass` tinyint(1) DEFAULT 0,
  `dshout_editown` tinyint(1) NOT NULL DEFAULT 0,
  `dshout_deleteown` tinyint(1) DEFAULT 0,
  `last_shout_time` int(11) NOT NULL DEFAULT 0,
  `sb_shoutboxtype` char(1) DEFAULT 'D',
  `sb_showavatars` char(1) DEFAULT 'D',
  `sb_showshouttime` char(1) DEFAULT 'D',
  `sb_defaultcolor` varchar(100) DEFAULT 'D',
  `sb_refresh` varchar(100) DEFAULT 'D',
  `sb_showsmiliest` char(1) DEFAULT 'D',
  `sb_showtdshouters` char(1) DEFAULT 'D',
  `sb_showtpshouters` char(1) DEFAULT 'D',
  `sb_gsbtype` char(1) NOT NULL DEFAULT 'D',
  `sb_gsbrefresh` tinyint(1) NOT NULL DEFAULT 0,
  `sb_gsbstyle` char(1) NOT NULL DEFAULT 'N',
  `user_sort` varchar(15) NOT NULL DEFAULT '0',
  `user_order` varchar(4) NOT NULL DEFAULT '0',
  `user_g_pp` mediumint(8) NOT NULL DEFAULT 0,
  `user_s_pp` mediumint(8) NOT NULL DEFAULT 0,
  `def_g_cat` mediumint(8) NOT NULL DEFAULT 0,
  `game_skin` tinyint(1) NOT NULL DEFAULT 0,
  `arcade_mod_privs` text NOT NULL,
  `a_minerals` int(11) NOT NULL DEFAULT 0,
  `space` int(10) NOT NULL DEFAULT 0,
  `menutoggle` tinyint(1) NOT NULL DEFAULT 1,
  `menubrowser` varchar(4) NOT NULL DEFAULT 'auto',
  `menulinks` varchar(100) NOT NULL DEFAULT '',
  `gavekarma` text DEFAULT NULL,
  `karma` smallint(4) NOT NULL DEFAULT 0,
  `karmapoints` tinyint(5) NOT NULL DEFAULT 0,
  `donations` mediumint(2) NOT NULL DEFAULT 0,
  `dlapprove` mediumint(9) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `mgroup` (`mgroup`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_member_extra`;
CREATE TABLE `ibf_member_extra` (
  `id` mediumint(8) NOT NULL DEFAULT 0,
  `notes` text DEFAULT NULL,
  `mem_notes` longtext DEFAULT NULL,
  `links` text DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `ta_size` char(3) DEFAULT NULL,
  `photo_type` varchar(10) DEFAULT '',
  `photo_location` varchar(255) DEFAULT '',
  `photo_dimensions` varchar(200) DEFAULT '',
  `vdirs` text NOT NULL,
  `location` varchar(250) NOT NULL DEFAULT '',
  `signature` text NOT NULL,
  `avatar_location` varchar(128) NOT NULL DEFAULT '',
  `avatar_size` varchar(9) NOT NULL DEFAULT '',
  `avatar_type` varchar(15) NOT NULL DEFAULT 'local',
  `signature_location` varchar(128) NOT NULL DEFAULT '',
  `signature_size` varchar(9) NOT NULL DEFAULT '',
  `signature_type` varchar(15) NOT NULL DEFAULT 'local',
  `emo_fav` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_memrates`;
CREATE TABLE `ibf_memrates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ratedid` int(11) NOT NULL DEFAULT 0,
  `mid` int(11) NOT NULL DEFAULT 0,
  `mname` varchar(100) NOT NULL DEFAULT '',
  `ip_address` varchar(20) NOT NULL DEFAULT '',
  `ratedate` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_memrates_master`;
CREATE TABLE `ibf_memrates_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ratedid` int(11) NOT NULL DEFAULT 0,
  `mid` int(11) NOT NULL DEFAULT 0,
  `mname` varchar(100) NOT NULL DEFAULT '',
  `ip_address` varchar(20) NOT NULL DEFAULT '',
  `ratedate` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_message_text`;
CREATE TABLE `ibf_message_text` (
  `msg_id` int(10) NOT NULL AUTO_INCREMENT,
  `msg_date` int(10) DEFAULT NULL,
  `msg_post` text DEFAULT NULL,
  `msg_cc_users` text DEFAULT NULL,
  `msg_sent_to_count` smallint(5) NOT NULL DEFAULT 0,
  `msg_deleted_count` smallint(5) NOT NULL DEFAULT 0,
  `msg_post_key` varchar(32) NOT NULL DEFAULT '0',
  `msg_author_id` mediumint(8) NOT NULL DEFAULT 0,
  PRIMARY KEY (`msg_id`),
  KEY `msg_date` (`msg_date`),
  KEY `msg_sent_to_count` (`msg_sent_to_count`),
  KEY `msg_deleted_count` (`msg_deleted_count`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_message_topics`;
CREATE TABLE `ibf_message_topics` (
  `mt_id` int(10) NOT NULL AUTO_INCREMENT,
  `mt_msg_id` int(10) NOT NULL DEFAULT 0,
  `mt_date` int(10) NOT NULL DEFAULT 0,
  `mt_title` varchar(255) NOT NULL DEFAULT '',
  `mt_from_id` mediumint(8) NOT NULL DEFAULT 0,
  `mt_to_id` mediumint(8) NOT NULL DEFAULT 0,
  `mt_owner_id` mediumint(8) NOT NULL DEFAULT 0,
  `mt_vid_folder` varchar(32) NOT NULL DEFAULT '',
  `mt_read` tinyint(1) NOT NULL DEFAULT 0,
  `mt_hasattach` smallint(5) NOT NULL DEFAULT 0,
  `mt_hide_cc` tinyint(1) DEFAULT 0,
  `mt_tracking` tinyint(1) DEFAULT 0,
  `mt_user_read` int(10) DEFAULT 0,
  PRIMARY KEY (`mt_id`),
  KEY `mt_from_id` (`mt_from_id`),
  KEY `mt_owner_id` (`mt_owner_id`,`mt_to_id`,`mt_vid_folder`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_pages`;
CREATE TABLE `ibf_pages` (
  `id` int(3) unsigned NOT NULL AUTO_INCREMENT,
  `line_break` char(1) NOT NULL DEFAULT '1',
  `on_smile` char(1) NOT NULL DEFAULT '1',
  `alias` varchar(10) NOT NULL DEFAULT '',
  `name` varchar(30) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_polls`;
CREATE TABLE `ibf_polls` (
  `pid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `tid` int(10) NOT NULL DEFAULT 0,
  `start_date` int(10) DEFAULT NULL,
  `choices` text DEFAULT NULL,
  `starter_id` mediumint(8) NOT NULL DEFAULT 0,
  `votes` smallint(5) NOT NULL DEFAULT 0,
  `forum_id` smallint(5) NOT NULL DEFAULT 0,
  `poll_question` varchar(255) DEFAULT NULL,
  `is_multi_poll` tinyint(1) NOT NULL DEFAULT 0,
  `multi_poll_min` tinyint(2) NOT NULL DEFAULT 0,
  `multi_poll_max` tinyint(2) NOT NULL DEFAULT 0,
  `is_weighted_poll` tinyint(1) NOT NULL DEFAULT 0,
  `weighted_poll_places` tinyint(2) NOT NULL DEFAULT 0,
  `poll_active` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_poll_results`;
CREATE TABLE `ibf_poll_results` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '',
  `primary_3` int(4) NOT NULL DEFAULT 0,
  `secondary_2` int(4) NOT NULL DEFAULT 0,
  `tertiary_1` int(4) NOT NULL DEFAULT 0,
  `total_votes` int(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_poll_voters`;
CREATE TABLE `ibf_poll_voters` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '',
  `primary_3` int(4) NOT NULL DEFAULT 0,
  `secondary_2` int(4) NOT NULL DEFAULT 0,
  `tertiary_1` int(4) NOT NULL DEFAULT 0,
  `ip_address` varchar(16) NOT NULL DEFAULT '',
  `referral` varchar(16) NOT NULL DEFAULT '',
  PRIMARY KEY (`name`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `ip_address` (`ip_address`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_posts`;
CREATE TABLE `ibf_posts` (
  `pid` int(10) NOT NULL AUTO_INCREMENT,
  `append_edit` tinyint(1) DEFAULT 0,
  `edit_time` int(10) DEFAULT NULL,
  `author_id` mediumint(8) NOT NULL DEFAULT 0,
  `author_name` varchar(32) DEFAULT NULL,
  `use_sig` tinyint(1) NOT NULL DEFAULT 0,
  `use_emo` tinyint(1) NOT NULL DEFAULT 0,
  `ip_address` varchar(16) NOT NULL DEFAULT '',
  `post_date` int(10) DEFAULT NULL,
  `icon_id` smallint(3) DEFAULT NULL,
  `post` text DEFAULT NULL,
  `queued` tinyint(1) NOT NULL DEFAULT 0,
  `topic_id` int(10) NOT NULL DEFAULT 0,
  `post_title` varchar(255) DEFAULT NULL,
  `new_topic` tinyint(1) DEFAULT 0,
  `edit_name` varchar(255) DEFAULT NULL,
  `post_parent` int(10) NOT NULL DEFAULT 0,
  `post_key` varchar(32) NOT NULL DEFAULT '0',
  `post_htmlstate` smallint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`pid`),
  KEY `topic_id` (`topic_id`,`queued`,`pid`),
  KEY `author_id` (`author_id`,`topic_id`),
  KEY `post_date` (`post_date`),
  FULLTEXT KEY `post` (`post`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_quotes`;
CREATE TABLE `ibf_quotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quote` text NOT NULL,
  `accepted` char(1) NOT NULL DEFAULT 'N',
  `num` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_quotes_logs`;
CREATE TABLE `ibf_quotes_logs` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `quote` text NOT NULL,
  `ip` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_raffle`;
CREATE TABLE `ibf_raffle` (
  `drawday` date DEFAULT NULL,
  `winnerid` varchar(255) DEFAULT NULL,
  `pot` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_raffle_settings`;
CREATE TABLE `ibf_raffle_settings` (
  `cost` varchar(10) DEFAULT NULL,
  `topcount` int(11) DEFAULT NULL,
  `timetodraw` varchar(255) DEFAULT NULL,
  `rafflename` varchar(255) DEFAULT NULL,
  `maxticket` int(11) DEFAULT NULL,
  `startwith` int(11) DEFAULT NULL,
  `daystodraw` varchar(255) DEFAULT NULL,
  `added` int(11) DEFAULT NULL,
  `allowed_groups` varchar(100) DEFAULT NULL,
  `multiplier` varchar(4) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_sessions`;
CREATE TABLE `ibf_sessions` (
  `id` varchar(32) NOT NULL DEFAULT '0',
  `member_name` varchar(64) DEFAULT NULL,
  `member_id` mediumint(8) NOT NULL DEFAULT 0,
  `ip_address` varchar(16) DEFAULT NULL,
  `browser` varchar(64) DEFAULT NULL,
  `running_time` int(10) DEFAULT NULL,
  `login_type` tinyint(1) DEFAULT NULL,
  `location` varchar(40) DEFAULT NULL,
  `member_group` smallint(3) DEFAULT NULL,
  `in_forum` smallint(5) NOT NULL DEFAULT 0,
  `in_topic` int(10) DEFAULT NULL,
  `member_icon` varchar(48) DEFAULT 'no_icon.gif',
  `in_down` int(10) NOT NULL DEFAULT 0,
  `in_downcat` int(10) NOT NULL DEFAULT 0,
  `in_error` tinyint(1) NOT NULL DEFAULT 0,
  `in_dldo` varchar(30) DEFAULT NULL,
  `in_dlcat` varchar(30) DEFAULT NULL,
  `in_dlfile` mediumint(8) DEFAULT NULL,
  `in_do` varchar(30) DEFAULT NULL,
  `in_cat` varchar(30) DEFAULT NULL,
  `in_id` mediumint(8) DEFAULT NULL,
  `parsed_browser` varchar(50) NOT NULL DEFAULT 'none',
  `in_game` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `in_topic` (`in_topic`),
  KEY `in_forum` (`in_forum`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_shoutbox`;
CREATE TABLE `ibf_shoutbox` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `uid` int(11) NOT NULL DEFAULT 0,
  `mgroup` int(11) NOT NULL DEFAULT 0,
  `shout` longtext NOT NULL,
  `color` varchar(100) NOT NULL DEFAULT '',
  `date` varchar(255) NOT NULL DEFAULT '',
  `time` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_shoutbox_colors`;
CREATE TABLE `ibf_shoutbox_colors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `color` varchar(255) NOT NULL DEFAULT '',
  `cname` varchar(255) DEFAULT NULL,
  `corder` int(5) DEFAULT NULL,
  `visible` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_shoutbox_exports`;
CREATE TABLE `ibf_shoutbox_exports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL DEFAULT '',
  `filesize` int(11) DEFAULT NULL,
  `type` varchar(4) NOT NULL DEFAULT '',
  `date` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_shoutbox_ignored`;
CREATE TABLE `ibf_shoutbox_ignored` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mid` int(11) NOT NULL DEFAULT 0,
  `uid` int(11) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL DEFAULT '',
  `grp` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_shoutbox_savedshouts`;
CREATE TABLE `ibf_shoutbox_savedshouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shouter` varchar(255) NOT NULL DEFAULT '',
  `mid` int(11) NOT NULL DEFAULT 0,
  `mgroup` int(11) NOT NULL DEFAULT 0,
  `shout` longtext NOT NULL,
  `color` varchar(255) NOT NULL DEFAULT '',
  `shouttime` int(11) NOT NULL DEFAULT 0,
  `last_edit` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_shoutbox_settings`;
CREATE TABLE `ibf_shoutbox_settings` (
  `set_id` int(5) NOT NULL AUTO_INCREMENT,
  `set_group` int(3) NOT NULL DEFAULT 0,
  `set_name` varchar(255) NOT NULL DEFAULT '',
  `set_title` varchar(255) NOT NULL DEFAULT '',
  `set_desc` text NOT NULL,
  `set_value` text DEFAULT NULL,
  `set_default` text NOT NULL,
  `set_type` char(2) NOT NULL DEFAULT '',
  `set_order` int(3) NOT NULL DEFAULT 0,
  `set_options` text DEFAULT NULL,
  `set_cols` tinyint(3) DEFAULT NULL,
  `set_rows` tinyint(3) DEFAULT NULL,
  PRIMARY KEY (`set_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_shoutbox_stats`;
CREATE TABLE `ibf_shoutbox_stats` (
  `totalshouts` int(11) DEFAULT NULL,
  `shouts_today` int(11) DEFAULT NULL,
  `shouts_alltime` int(11) DEFAULT NULL,
  `lastshout_date` varchar(50) DEFAULT NULL,
  `sbox_tbadwords` int(11) DEFAULT NULL,
  `sbox_tcolors` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_skin_macro`;
CREATE TABLE `ibf_skin_macro` (
  `macro_id` smallint(3) NOT NULL AUTO_INCREMENT,
  `macro_value` varchar(200) DEFAULT NULL,
  `macro_replace` text DEFAULT NULL,
  `macro_can_remove` tinyint(1) DEFAULT 0,
  `macro_set` smallint(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`macro_id`),
  KEY `macro_set` (`macro_set`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_skin_sets`;
CREATE TABLE `ibf_skin_sets` (
  `set_skin_set_id` int(10) NOT NULL AUTO_INCREMENT,
  `set_name` varchar(150) NOT NULL DEFAULT '',
  `set_image_dir` varchar(200) NOT NULL DEFAULT '',
  `set_hidden` tinyint(1) NOT NULL DEFAULT 0,
  `set_default` tinyint(1) NOT NULL DEFAULT 0,
  `set_css_method` varchar(100) NOT NULL DEFAULT 'inline',
  `set_skin_set_parent` smallint(5) NOT NULL DEFAULT -1,
  `set_author_email` varchar(255) NOT NULL DEFAULT '',
  `set_author_name` varchar(255) NOT NULL DEFAULT '',
  `set_author_url` varchar(255) NOT NULL DEFAULT '',
  `set_css` mediumtext NOT NULL,
  `set_wrapper` mediumtext NOT NULL,
  `set_css_updated` int(10) NOT NULL DEFAULT 0,
  `set_cache_css` mediumtext NOT NULL,
  `set_cache_macro` mediumtext NOT NULL,
  `set_cache_wrapper` mediumtext NOT NULL,
  `set_emoticon_folder` varchar(60) NOT NULL DEFAULT 'default',
  PRIMARY KEY (`set_skin_set_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_skin_templates`;
CREATE TABLE `ibf_skin_templates` (
  `suid` int(10) NOT NULL AUTO_INCREMENT,
  `set_id` int(10) NOT NULL DEFAULT 0,
  `group_name` varchar(255) NOT NULL DEFAULT '',
  `section_content` mediumtext DEFAULT NULL,
  `func_name` varchar(255) DEFAULT NULL,
  `func_data` text DEFAULT NULL,
  `updated` int(10) DEFAULT NULL,
  `can_remove` tinyint(4) DEFAULT 0,
  PRIMARY KEY (`suid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_skin_templates_cache`;
CREATE TABLE `ibf_skin_templates_cache` (
  `template_id` varchar(32) NOT NULL DEFAULT '',
  `template_group_name` varchar(255) NOT NULL DEFAULT '',
  `template_group_content` mediumtext NOT NULL,
  `template_set_id` int(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`template_id`),
  KEY `template_set_id` (`template_set_id`),
  KEY `template_group_name` (`template_group_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_statistics_data`;
CREATE TABLE `ibf_statistics_data` (
  `id` tinyint(2) NOT NULL AUTO_INCREMENT,
  `enable` tinyint(1) NOT NULL DEFAULT 1,
  `title` varchar(64) NOT NULL DEFAULT '',
  `link` text NOT NULL,
  `data` text NOT NULL,
  `updated` int(16) NOT NULL DEFAULT 0,
  `groupid` tinyint(1) NOT NULL DEFAULT 0,
  `qdatatype` varchar(16) NOT NULL DEFAULT '',
  `qquery` varchar(255) NOT NULL DEFAULT '',
  `qlimit` tinyint(2) NOT NULL DEFAULT 10,
  `qordering` tinyint(2) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  FULLTEXT KEY `data` (`link`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_statistics_groups`;
CREATE TABLE `ibf_statistics_groups` (
  `gid` mediumint(2) NOT NULL DEFAULT 0,
  `g_order` tinyint(2) NOT NULL DEFAULT 0,
  `g_name` varchar(64) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_titles`;
CREATE TABLE `ibf_titles` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `posts` int(10) DEFAULT NULL,
  `title` varchar(128) DEFAULT NULL,
  `pips` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_topics`;
CREATE TABLE `ibf_topics` (
  `tid` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(70) NOT NULL DEFAULT '',
  `description` varchar(70) DEFAULT NULL,
  `state` varchar(8) DEFAULT NULL,
  `posts` int(10) DEFAULT NULL,
  `starter_id` mediumint(8) NOT NULL DEFAULT 0,
  `start_date` int(10) DEFAULT NULL,
  `last_poster_id` mediumint(8) NOT NULL DEFAULT 0,
  `last_post` int(10) DEFAULT NULL,
  `icon_id` tinyint(2) DEFAULT NULL,
  `starter_name` varchar(32) DEFAULT NULL,
  `last_poster_name` varchar(32) DEFAULT NULL,
  `poll_state` varchar(8) DEFAULT NULL,
  `last_vote` int(10) DEFAULT NULL,
  `views` int(10) DEFAULT NULL,
  `forum_id` smallint(5) NOT NULL DEFAULT 0,
  `approved` tinyint(1) NOT NULL DEFAULT 0,
  `author_mode` tinyint(1) DEFAULT NULL,
  `pinned` tinyint(1) NOT NULL DEFAULT 0,
  `moved_to` varchar(64) DEFAULT NULL,
  `rating` text DEFAULT NULL,
  `total_votes` int(5) NOT NULL DEFAULT 0,
  `topic_hasattach` smallint(5) NOT NULL DEFAULT 0,
  `topic_firstpost` int(10) NOT NULL DEFAULT 0,
  `topic_queuedposts` int(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`tid`),
  KEY `last_post` (`last_post`),
  KEY `forum_id` (`forum_id`,`approved`,`pinned`),
  KEY `topic_firstpost` (`topic_firstpost`),
  FULLTEXT KEY `title` (`title`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_topics_read`;
CREATE TABLE `ibf_topics_read` (
  `read_tid` int(10) NOT NULL DEFAULT 0,
  `read_mid` mediumint(8) NOT NULL DEFAULT 0,
  `read_date` int(10) NOT NULL DEFAULT 0,
  UNIQUE KEY `read_tid_mid` (`read_tid`,`read_mid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_topic_mmod`;
CREATE TABLE `ibf_topic_mmod` (
  `mm_id` smallint(5) NOT NULL AUTO_INCREMENT,
  `mm_title` varchar(250) NOT NULL DEFAULT '',
  `mm_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `topic_state` varchar(10) NOT NULL DEFAULT 'leave',
  `topic_pin` varchar(10) NOT NULL DEFAULT 'leave',
  `topic_move` smallint(5) NOT NULL DEFAULT 0,
  `topic_move_link` tinyint(1) NOT NULL DEFAULT 0,
  `topic_title_st` varchar(250) NOT NULL DEFAULT '',
  `topic_title_end` varchar(250) NOT NULL DEFAULT '',
  `topic_reply` tinyint(1) NOT NULL DEFAULT 0,
  `topic_reply_content` text NOT NULL,
  `topic_reply_postcount` tinyint(1) NOT NULL DEFAULT 0,
  `mm_forums` text NOT NULL,
  `topic_approve` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`mm_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_tutorials`;
CREATE TABLE `ibf_tutorials` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL DEFAULT 0,
  `status` enum('pending','aproved') NOT NULL DEFAULT 'pending',
  `title` varchar(128) NOT NULL DEFAULT '',
  `author_name` varchar(32) NOT NULL DEFAULT '',
  `tutorial` mediumtext NOT NULL,
  `num_votes` tinyint(4) NOT NULL DEFAULT 0,
  `total_votes` bigint(10) NOT NULL DEFAULT 0,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `views` bigint(10) NOT NULL DEFAULT 0,
  `rate` float NOT NULL DEFAULT 0,
  `n_comments` smallint(3) NOT NULL DEFAULT 0,
  `author_id` mediumint(8) NOT NULL DEFAULT 0,
  `tut_source` varchar(128) NOT NULL DEFAULT '',
  `tut_desc` mediumtext NOT NULL,
  `tut_tid` mediumint(4) NOT NULL DEFAULT 0,
  `tut_pid` mediumint(4) NOT NULL DEFAULT 0,
  `link_tut` varchar(128) NOT NULL DEFAULT '',
  `link_top` varchar(128) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_tutorialsv2`;
CREATE TABLE `ibf_tutorialsv2` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `title` varchar(64) NOT NULL DEFAULT '?????',
  `author` varchar(50) NOT NULL DEFAULT '?????',
  `category` varchar(32) NOT NULL DEFAULT '',
  `skill_level` tinyint(1) NOT NULL DEFAULT 0,
  `views` int(4) NOT NULL DEFAULT 0,
  `dated` varchar(32) NOT NULL DEFAULT '',
  `text` text NOT NULL,
  `files` varchar(32) DEFAULT NULL,
  `topics` varchar(32) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `submit_id` mediumint(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  FULLTEXT KEY `text` (`text`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_tutorialsv2_cats`;
CREATE TABLE `ibf_tutorialsv2_cats` (
  `sqlname` varchar(32) NOT NULL DEFAULT '',
  `realname` varchar(32) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_tut_comments`;
CREATE TABLE `ibf_tut_comments` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `tid` int(4) NOT NULL DEFAULT 0,
  `owner` varchar(25) NOT NULL DEFAULT '',
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `COMMENT` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_tut_config`;
CREATE TABLE `ibf_tut_config` (
  `ubbc` int(1) NOT NULL DEFAULT 0,
  `guests` smallint(1) NOT NULL DEFAULT 0,
  `sub` smallint(1) NOT NULL DEFAULT 0,
  `uplo` smallint(1) NOT NULL DEFAULT 0,
  `uplo_perms` varchar(128) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_tut_rel_links`;
CREATE TABLE `ibf_tut_rel_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tid` int(4) NOT NULL DEFAULT 0,
  `link` text NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_tut_sections`;
CREATE TABLE `ibf_tut_sections` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ibf_voters`;
CREATE TABLE `ibf_voters` (
  `vid` int(10) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(16) NOT NULL DEFAULT '',
  `vote_date` int(10) NOT NULL DEFAULT 0,
  `tid` int(10) NOT NULL DEFAULT 0,
  `member_id` varchar(32) DEFAULT NULL,
  `forum_id` smallint(5) NOT NULL DEFAULT 0,
  PRIMARY KEY (`vid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


-- 2017-04-30 18:06:47
