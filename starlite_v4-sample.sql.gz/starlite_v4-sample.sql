-- phpMyAdmin SQL Dump
-- version 4.0.10.14
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Apr 10, 2017 at 04:23 PM
-- Server version: 5.5.52-cll
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `starlite_v4`
--
CREATE DATABASE IF NOT EXISTS `starlite_v4` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `starlite_v4`;

-- --------------------------------------------------------

--
-- Table structure for table `apass`
--

CREATE TABLE IF NOT EXISTS `apass` (
  `mid` mediumint(8) NOT NULL DEFAULT '0',
  `hash` varchar(64) NOT NULL DEFAULT '',
  `pass` varchar(128) NOT NULL DEFAULT '',
  PRIMARY KEY (`mid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_abuse_iso`
--

CREATE TABLE IF NOT EXISTS `ibf_abuse_iso` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `mid` int(8) NOT NULL DEFAULT '0',
  `ip` varchar(32) NOT NULL DEFAULT '',
  `pro` varchar(16) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1008 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_admin_logs`
--

CREATE TABLE IF NOT EXISTS `ibf_admin_logs` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `act` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `member_id` int(10) DEFAULT NULL,
  `ctime` int(10) DEFAULT NULL,
  `note` text,
  `ip_address` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5237 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_admin_sessions`
--

CREATE TABLE IF NOT EXISTS `ibf_admin_sessions` (
  `session_id` varchar(32) NOT NULL DEFAULT '',
  `session_ip_address` varchar(32) NOT NULL DEFAULT '',
  `session_member_name` varchar(250) NOT NULL DEFAULT '',
  `session_member_id` mediumint(8) NOT NULL DEFAULT '0',
  `session_member_login_key` varchar(32) NOT NULL DEFAULT '',
  `session_location` varchar(64) NOT NULL DEFAULT '',
  `session_log_in_time` int(10) NOT NULL DEFAULT '0',
  `session_running_time` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`session_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_affiliates`
--

CREATE TABLE IF NOT EXISTS `ibf_affiliates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(225) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `clicks` int(11) NOT NULL DEFAULT '0',
  `accepted` char(1) NOT NULL DEFAULT 'N',
  `display` int(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=46 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_announcements`
--

CREATE TABLE IF NOT EXISTS `ibf_announcements` (
  `announce_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `announce_title` varchar(255) NOT NULL DEFAULT '',
  `announce_post` text NOT NULL,
  `announce_forum` text NOT NULL,
  `announce_member_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `announce_html_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `announce_views` int(10) unsigned NOT NULL DEFAULT '0',
  `announce_start` int(10) unsigned NOT NULL DEFAULT '0',
  `announce_end` int(10) unsigned NOT NULL DEFAULT '0',
  `announce_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`announce_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_attachments`
--

CREATE TABLE IF NOT EXISTS `ibf_attachments` (
  `attach_id` int(10) NOT NULL AUTO_INCREMENT,
  `attach_ext` varchar(10) NOT NULL DEFAULT '',
  `attach_file` varchar(250) NOT NULL DEFAULT '',
  `attach_location` varchar(250) NOT NULL DEFAULT '',
  `attach_thumb_location` varchar(250) NOT NULL DEFAULT '',
  `attach_thumb_width` smallint(5) NOT NULL DEFAULT '0',
  `attach_thumb_height` smallint(5) NOT NULL DEFAULT '0',
  `attach_is_image` tinyint(1) NOT NULL DEFAULT '0',
  `attach_hits` int(10) NOT NULL DEFAULT '0',
  `attach_date` int(10) NOT NULL DEFAULT '0',
  `attach_temp` tinyint(1) NOT NULL DEFAULT '0',
  `attach_pid` int(10) NOT NULL DEFAULT '0',
  `attach_post_key` varchar(32) NOT NULL DEFAULT '0',
  `attach_msg` int(10) NOT NULL DEFAULT '0',
  `attach_member_id` mediumint(8) NOT NULL DEFAULT '0',
  `attach_approved` int(10) NOT NULL DEFAULT '1',
  `attach_filesize` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`attach_id`),
  KEY `attach_pid` (`attach_pid`),
  KEY `attach_msg` (`attach_msg`),
  KEY `attach_post_key` (`attach_post_key`),
  KEY `attach_mid_size` (`attach_member_id`,`attach_filesize`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23034 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_attachments_type`
--

CREATE TABLE IF NOT EXISTS `ibf_attachments_type` (
  `atype_id` int(10) NOT NULL AUTO_INCREMENT,
  `atype_extension` varchar(18) NOT NULL DEFAULT '',
  `atype_mimetype` varchar(255) NOT NULL DEFAULT '',
  `atype_post` tinyint(1) NOT NULL DEFAULT '1',
  `atype_photo` tinyint(1) NOT NULL DEFAULT '0',
  `atype_img` text NOT NULL,
  PRIMARY KEY (`atype_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=47 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_badwords`
--

CREATE TABLE IF NOT EXISTS `ibf_badwords` (
  `wid` int(3) NOT NULL AUTO_INCREMENT,
  `type` varchar(250) NOT NULL DEFAULT '',
  `swop` varchar(250) DEFAULT NULL,
  `m_exact` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`wid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=125 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_banfilters`
--

CREATE TABLE IF NOT EXISTS `ibf_banfilters` (
  `ban_id` int(10) NOT NULL AUTO_INCREMENT,
  `ban_type` varchar(10) NOT NULL DEFAULT 'ip',
  `ban_content` text NOT NULL,
  `ban_date` int(10) NOT NULL DEFAULT '0',
  `ban_comment` text NOT NULL,
  PRIMARY KEY (`ban_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=266 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_battlelog`
--

CREATE TABLE IF NOT EXISTS `ibf_battlelog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bid` int(11) NOT NULL DEFAULT '0',
  `attacker` text NOT NULL,
  `opponent` text NOT NULL,
  `move` text NOT NULL,
  `hpl` text NOT NULL,
  `mpl` text NOT NULL,
  `dmg` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1106 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_bulk_mail`
--

CREATE TABLE IF NOT EXISTS `ibf_bulk_mail` (
  `mail_id` int(10) NOT NULL AUTO_INCREMENT,
  `mail_subject` varchar(255) NOT NULL DEFAULT '',
  `mail_content` mediumtext NOT NULL,
  `mail_groups` mediumtext NOT NULL,
  `mail_honor` tinyint(1) NOT NULL DEFAULT '1',
  `mail_opts` mediumtext NOT NULL,
  `mail_start` int(10) NOT NULL DEFAULT '0',
  `mail_updated` int(10) NOT NULL DEFAULT '0',
  `mail_sentto` int(10) NOT NULL DEFAULT '0',
  `mail_active` tinyint(1) NOT NULL DEFAULT '0',
  `mail_pergo` smallint(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`mail_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_cache_store`
--

CREATE TABLE IF NOT EXISTS `ibf_cache_store` (
  `cs_key` varchar(255) NOT NULL DEFAULT '',
  `cs_value` mediumtext NOT NULL,
  `cs_extra` varchar(255) NOT NULL DEFAULT '',
  `cs_array` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cs_key`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_calendar_events`
--

CREATE TABLE IF NOT EXISTS `ibf_calendar_events` (
  `eventid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `userid` mediumint(8) NOT NULL DEFAULT '0',
  `year` int(4) NOT NULL DEFAULT '2002',
  `month` int(2) NOT NULL DEFAULT '1',
  `mday` int(2) NOT NULL DEFAULT '1',
  `title` varchar(254) NOT NULL DEFAULT 'no title',
  `event_text` text NOT NULL,
  `read_perms` varchar(254) NOT NULL DEFAULT '*',
  `unix_stamp` int(10) NOT NULL DEFAULT '0',
  `priv_event` tinyint(1) NOT NULL DEFAULT '0',
  `show_emoticons` tinyint(1) NOT NULL DEFAULT '1',
  `rating` smallint(2) NOT NULL DEFAULT '1',
  `event_ranged` tinyint(1) NOT NULL DEFAULT '0',
  `event_repeat` tinyint(1) NOT NULL DEFAULT '0',
  `repeat_unit` char(2) NOT NULL DEFAULT '',
  `end_day` int(2) DEFAULT NULL,
  `end_month` int(2) DEFAULT NULL,
  `end_year` int(4) DEFAULT NULL,
  `end_unix_stamp` int(10) DEFAULT NULL,
  `event_bgcolor` varchar(32) NOT NULL DEFAULT '',
  `event_color` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`eventid`),
  KEY `unix_stamp` (`unix_stamp`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_category`
--

CREATE TABLE IF NOT EXISTS `ibf_category` (
  `cid` smallint(4) NOT NULL AUTO_INCREMENT,
  `title` char(32) NOT NULL DEFAULT '',
  `parent` smallint(4) DEFAULT '0',
  `content` smallint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `name` (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_chess`
--

CREATE TABLE IF NOT EXISTS `ibf_chess` (
  `id` int(8) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `turn` mediumint(8) NOT NULL DEFAULT '0',
  `ranked` tinyint(1) NOT NULL DEFAULT '0',
  `wager` tinyint(2) NOT NULL DEFAULT '0',
  `length` mediumint(4) DEFAULT NULL,
  `cdate` mediumint(16) NOT NULL DEFAULT '0',
  `wmid` mediumint(8) NOT NULL DEFAULT '0',
  `wpieces` varchar(160) NOT NULL DEFAULT '',
  `wlmtime` mediumint(16) DEFAULT NULL,
  `wlmloc` varchar(8) DEFAULT NULL,
  `bmid` mediumint(8) NOT NULL DEFAULT '0',
  `bpieces` varchar(160) NOT NULL DEFAULT '',
  `blmtime` mediumint(16) DEFAULT NULL,
  `blmloc` varchar(8) DEFAULT NULL,
  `history` text,
  PRIMARY KEY (`id`),
  KEY `turn` (`turn`),
  FULLTEXT KEY `history` (`history`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_clanoptions`
--

CREATE TABLE IF NOT EXISTS `ibf_clanoptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cost` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_conf_settings`
--

CREATE TABLE IF NOT EXISTS `ibf_conf_settings` (
  `conf_id` int(10) NOT NULL AUTO_INCREMENT,
  `conf_title` varchar(255) NOT NULL DEFAULT '',
  `conf_description` text NOT NULL,
  `conf_group` varchar(255) NOT NULL DEFAULT '',
  `conf_type` varchar(255) NOT NULL DEFAULT '',
  `conf_key` varchar(255) NOT NULL DEFAULT '',
  `conf_value` text NOT NULL,
  `conf_default` text NOT NULL,
  `conf_extra` text NOT NULL,
  `conf_evalphp` text NOT NULL,
  `conf_protected` tinyint(1) NOT NULL DEFAULT '0',
  `conf_position` smallint(3) NOT NULL DEFAULT '0',
  `conf_start_group` varchar(255) NOT NULL DEFAULT '',
  `conf_end_group` tinyint(1) NOT NULL DEFAULT '0',
  `conf_help_key` varchar(255) NOT NULL DEFAULT '0',
  `conf_add_cache` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`conf_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=482 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_conf_settings_titles`
--

CREATE TABLE IF NOT EXISTS `ibf_conf_settings_titles` (
  `conf_title_id` smallint(3) NOT NULL AUTO_INCREMENT,
  `conf_title_title` varchar(255) NOT NULL DEFAULT '',
  `conf_title_desc` text NOT NULL,
  `conf_title_count` smallint(3) NOT NULL DEFAULT '0',
  `conf_title_noshow` tinyint(1) NOT NULL DEFAULT '0',
  `conf_title_keyword` varchar(200) NOT NULL DEFAULT '0',
  PRIMARY KEY (`conf_title_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=37 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_contacts`
--

CREATE TABLE IF NOT EXISTS `ibf_contacts` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `contact_id` mediumint(8) NOT NULL DEFAULT '0',
  `member_id` mediumint(8) NOT NULL DEFAULT '0',
  `contact_name` varchar(32) NOT NULL DEFAULT '',
  `allow_msg` tinyint(1) DEFAULT NULL,
  `contact_desc` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2277 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_content`
--

CREATE TABLE IF NOT EXISTS `ibf_content` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL DEFAULT '0',
  `title` varchar(128) NOT NULL DEFAULT '',
  `author` varchar(32) NOT NULL DEFAULT '',
  `data` text NOT NULL,
  `num_votes` tinyint(4) NOT NULL DEFAULT '0',
  `total_votes` bigint(10) NOT NULL DEFAULT '0',
  `date` int(10) DEFAULT NULL,
  `views` bigint(10) NOT NULL DEFAULT '0',
  `rate` float NOT NULL DEFAULT '0',
  `n_comments` smallint(3) NOT NULL DEFAULT '0',
  `open` tinyint(1) NOT NULL DEFAULT '0',
  `mid` mediumint(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=144 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_content_cat`
--

CREATE TABLE IF NOT EXISTS `ibf_content_cat` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `o` tinyint(4) NOT NULL DEFAULT '0',
  `title` varchar(128) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `number` mediumint(10) NOT NULL DEFAULT '0',
  `pview` varchar(255) DEFAULT NULL,
  `padd` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_content_settings`
--

CREATE TABLE IF NOT EXISTS `ibf_content_settings` (
  `online` tinyint(1) NOT NULL DEFAULT '1',
  `contents` varchar(128) DEFAULT NULL,
  `contentp` varchar(128) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_custom_bbcode`
--

CREATE TABLE IF NOT EXISTS `ibf_custom_bbcode` (
  `bbcode_id` int(10) NOT NULL AUTO_INCREMENT,
  `bbcode_title` varchar(255) NOT NULL DEFAULT '',
  `bbcode_desc` text NOT NULL,
  `bbcode_tag` varchar(255) NOT NULL DEFAULT '',
  `bbcode_replace` text NOT NULL,
  `bbcode_useoption` tinyint(1) NOT NULL DEFAULT '0',
  `bbcode_example` text NOT NULL,
  PRIMARY KEY (`bbcode_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_email_logs`
--

CREATE TABLE IF NOT EXISTS `ibf_email_logs` (
  `email_id` int(10) NOT NULL AUTO_INCREMENT,
  `email_subject` varchar(255) NOT NULL DEFAULT '',
  `email_content` text NOT NULL,
  `email_date` int(10) NOT NULL DEFAULT '0',
  `from_member_id` mediumint(8) NOT NULL DEFAULT '0',
  `from_email_address` varchar(250) NOT NULL DEFAULT '',
  `from_ip_address` varchar(16) NOT NULL DEFAULT '127.0.0.1',
  `to_member_id` mediumint(8) NOT NULL DEFAULT '0',
  `to_email_address` varchar(250) NOT NULL DEFAULT '',
  `topic_id` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`email_id`),
  KEY `from_member_id` (`from_member_id`),
  KEY `email_date` (`email_date`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=445 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_emoticons`
--

CREATE TABLE IF NOT EXISTS `ibf_emoticons` (
  `id` smallint(3) NOT NULL AUTO_INCREMENT,
  `typed` varchar(32) NOT NULL DEFAULT '',
  `image` varchar(128) NOT NULL DEFAULT '',
  `clickable` smallint(2) NOT NULL DEFAULT '1',
  `emo_set` varchar(64) NOT NULL DEFAULT 'default',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=175 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_failed_logins`
--

CREATE TABLE IF NOT EXISTS `ibf_failed_logins` (
  `name` varchar(64) NOT NULL DEFAULT '',
  `ip` varchar(16) NOT NULL DEFAULT '',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_faq`
--

CREATE TABLE IF NOT EXISTS `ibf_faq` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL DEFAULT '',
  `text` text,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_faq_adv`
--

CREATE TABLE IF NOT EXISTS `ibf_faq_adv` (
  `id` mediumint(2) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL DEFAULT '',
  `text` text NOT NULL,
  `description` text NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `updated` mediumint(16) DEFAULT NULL,
  `frominvis` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  FULLTEXT KEY `text` (`text`,`description`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_files`
--

CREATE TABLE IF NOT EXISTS `ibf_files` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `cat` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `fname` varchar(70) NOT NULL DEFAULT '',
  `fdesc` text NOT NULL,
  `author` varchar(75) NOT NULL DEFAULT '',
  `poster` varchar(75) NOT NULL DEFAULT '',
  `mid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `date` varchar(13) NOT NULL DEFAULT '',
  `updated` varchar(13) NOT NULL DEFAULT '',
  `views` smallint(5) unsigned NOT NULL DEFAULT '0',
  `downloads` smallint(6) NOT NULL DEFAULT '0',
  `topic` mediumint(8) NOT NULL DEFAULT '0',
  `open` tinyint(1) NOT NULL DEFAULT '0',
  `screenshot` varchar(250) NOT NULL DEFAULT '',
  `screenshot1` varchar(250) NOT NULL DEFAULT '',
  `votes` tinyint(4) NOT NULL DEFAULT '0',
  `total` tinyint(4) NOT NULL DEFAULT '0',
  `rating` tinyint(4) NOT NULL DEFAULT '0',
  `url` varchar(250) NOT NULL DEFAULT '',
  `link` varchar(250) NOT NULL DEFAULT '',
  `current` tinyint(1) NOT NULL DEFAULT '1',
  `ipaddress` varchar(32) NOT NULL DEFAULT '0',
  `is_broken` tinyint(1) NOT NULL DEFAULT '0',
  `mems_subs` text,
  `ext` char(3) DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6614 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_files_banfilter`
--

CREATE TABLE IF NOT EXISTS `ibf_files_banfilter` (
  `mid` mediumint(8) NOT NULL DEFAULT '0',
  `time` int(10) NOT NULL DEFAULT '0',
  `timeleft` int(11) NOT NULL DEFAULT '0',
  `reason` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_files_cats`
--

CREATE TABLE IF NOT EXISTS `ibf_files_cats` (
  `cid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `sub` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `cname` varchar(50) NOT NULL DEFAULT '',
  `cdesc` tinytext NOT NULL,
  `copen` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `dis_screen` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `dis_screen_cat` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `screen_req` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `authorize` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `fordaforum` smallint(5) unsigned NOT NULL DEFAULT '0',
  `position` tinyint(4) NOT NULL DEFAULT '0',
  `show_notes` tinyint(1) NOT NULL DEFAULT '0',
  `cnotes` tinytext NOT NULL,
  `group_perm` varchar(250) NOT NULL DEFAULT '*',
  `tot_files` mediumint(8) NOT NULL DEFAULT '0',
  `last_info` varchar(255) DEFAULT NULL,
  `type` tinyint(10) NOT NULL DEFAULT '0',
  UNIQUE KEY `id` (`cid`),
  KEY `position` (`position`),
  KEY `sub` (`sub`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_files_comments`
--

CREATE TABLE IF NOT EXISTS `ibf_files_comments` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `file_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `mem_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `name` varchar(75) NOT NULL DEFAULT '',
  `date` varchar(13) NOT NULL DEFAULT '0',
  `comment` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14033 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_files_custentered`
--

CREATE TABLE IF NOT EXISTS `ibf_files_custentered` (
  `file_id` mediumint(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`file_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_files_custfields`
--

CREATE TABLE IF NOT EXISTS `ibf_files_custfields` (
  `fid` smallint(5) NOT NULL AUTO_INCREMENT,
  `ftitle` varchar(200) NOT NULL DEFAULT '',
  `fcontent` text,
  `ftype` varchar(250) DEFAULT 'text',
  `freq` tinyint(1) NOT NULL DEFAULT '0',
  `fshow` tinyint(1) NOT NULL DEFAULT '0',
  `fmaxinput` smallint(6) DEFAULT '250',
  `ftopic` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`fid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_files_downloads`
--

CREATE TABLE IF NOT EXISTS `ibf_files_downloads` (
  `m_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `member_name` varchar(75) NOT NULL DEFAULT '',
  `downloaded` varchar(13) NOT NULL DEFAULT '0',
  `file_id` mediumint(8) NOT NULL DEFAULT '0',
  `file_name` varchar(70) NOT NULL DEFAULT '',
  KEY `id` (`m_id`),
  KEY `script_id` (`file_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_files_favorites`
--

CREATE TABLE IF NOT EXISTS `ibf_files_favorites` (
  `id` mediumint(8) NOT NULL DEFAULT '0',
  `mid` mediumint(8) NOT NULL DEFAULT '0',
  `mname` varchar(50) NOT NULL DEFAULT '',
  `fid` mediumint(8) NOT NULL DEFAULT '0',
  `fname` varchar(75) NOT NULL DEFAULT '',
  `date` varchar(13) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_files_reviews`
--

CREATE TABLE IF NOT EXISTS `ibf_files_reviews` (
  `review_id` int(4) NOT NULL AUTO_INCREMENT,
  `file_id` int(4) NOT NULL DEFAULT '0',
  `reviewer` varchar(32) NOT NULL DEFAULT '',
  `thoughts` text NOT NULL,
  `creativity` decimal(2,1) NOT NULL DEFAULT '0.0',
  `terrain` decimal(2,1) NOT NULL DEFAULT '0.0',
  `orginality` decimal(2,1) NOT NULL DEFAULT '0.0',
  `complexity` decimal(2,1) NOT NULL DEFAULT '0.0',
  `fun` decimal(2,1) NOT NULL DEFAULT '0.0',
  `overall` decimal(2,1) NOT NULL DEFAULT '0.0',
  `finished` char(3) NOT NULL DEFAULT 'No',
  PRIMARY KEY (`review_id`),
  FULLTEXT KEY `thoughts` (`thoughts`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=84 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_files_reviews_req`
--

CREATE TABLE IF NOT EXISTS `ibf_files_reviews_req` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `file_id` int(4) NOT NULL DEFAULT '0',
  `status` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_files_votes`
--

CREATE TABLE IF NOT EXISTS `ibf_files_votes` (
  `mid` mediumint(8) NOT NULL DEFAULT '0',
  `rating` tinyint(1) NOT NULL DEFAULT '0',
  `did` mediumint(8) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_forums`
--

CREATE TABLE IF NOT EXISTS `ibf_forums` (
  `id` smallint(5) NOT NULL DEFAULT '0',
  `topics` mediumint(6) DEFAULT '0',
  `posts` mediumint(6) DEFAULT '0',
  `last_post` int(10) DEFAULT NULL,
  `last_poster_id` mediumint(8) NOT NULL DEFAULT '0',
  `last_poster_name` varchar(32) DEFAULT NULL,
  `name` varchar(128) NOT NULL DEFAULT '',
  `description` text,
  `position` tinyint(2) DEFAULT NULL,
  `use_ibc` tinyint(1) DEFAULT NULL,
  `use_html` tinyint(1) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `last_title` varchar(128) DEFAULT NULL,
  `last_id` int(10) DEFAULT NULL,
  `sort_key` varchar(32) DEFAULT NULL,
  `sort_order` varchar(32) DEFAULT NULL,
  `prune` tinyint(3) DEFAULT NULL,
  `show_rules` tinyint(1) DEFAULT NULL,
  `preview_posts` tinyint(1) DEFAULT NULL,
  `allow_poll` tinyint(1) NOT NULL DEFAULT '1',
  `allow_pollbump` tinyint(1) NOT NULL DEFAULT '0',
  `inc_postcount` tinyint(1) NOT NULL DEFAULT '1',
  `skin_id` int(10) DEFAULT NULL,
  `parent_id` mediumint(5) DEFAULT '-1',
  `sub_can_post` tinyint(1) DEFAULT '1',
  `quick_reply` tinyint(1) DEFAULT '0',
  `redirect_url` varchar(250) DEFAULT '',
  `redirect_on` tinyint(1) NOT NULL DEFAULT '0',
  `redirect_hits` int(10) NOT NULL DEFAULT '0',
  `redirect_loc` varchar(250) DEFAULT '',
  `rules_title` varchar(255) NOT NULL DEFAULT '',
  `rules_text` text NOT NULL,
  `topic_mm_id` varchar(250) NOT NULL DEFAULT '',
  `notify_modq_emails` text,
  `permission_custom_error` text NOT NULL,
  `permission_array` mediumtext NOT NULL,
  `permission_showtopic` tinyint(1) NOT NULL DEFAULT '0',
  `queued_topics` mediumint(6) NOT NULL DEFAULT '0',
  `queued_posts` mediumint(6) NOT NULL DEFAULT '0',
  `icon` text NOT NULL,
  `start` text,
  `activity` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `position` (`position`,`parent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_forumscounter`
--

CREATE TABLE IF NOT EXISTS `ibf_forumscounter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page` varchar(50) NOT NULL DEFAULT '',
  `hits` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=51 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_forums_bans`
--

CREATE TABLE IF NOT EXISTS `ibf_forums_bans` (
  `mid` mediumint(11) NOT NULL DEFAULT '0',
  `fid` int(2) NOT NULL DEFAULT '0',
  `bname` varchar(32) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_forum_perms`
--

CREATE TABLE IF NOT EXISTS `ibf_forum_perms` (
  `perm_id` int(10) NOT NULL AUTO_INCREMENT,
  `perm_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`perm_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_forum_tracker`
--

CREATE TABLE IF NOT EXISTS `ibf_forum_tracker` (
  `frid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `member_id` varchar(32) NOT NULL DEFAULT '',
  `forum_id` smallint(5) NOT NULL DEFAULT '0',
  `start_date` int(10) DEFAULT NULL,
  `last_sent` int(10) NOT NULL DEFAULT '0',
  `forum_track_type` varchar(100) NOT NULL DEFAULT 'delayed',
  PRIMARY KEY (`frid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=227 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_games_cats`
--

CREATE TABLE IF NOT EXISTS `ibf_games_cats` (
  `c_id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(32) NOT NULL DEFAULT '',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `show_all` tinyint(1) NOT NULL DEFAULT '0',
  `pos` tinyint(2) NOT NULL DEFAULT '1',
  `password` varchar(32) NOT NULL DEFAULT '',
  `num_of_games` mediumint(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`c_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_games_champs`
--

CREATE TABLE IF NOT EXISTS `ibf_games_champs` (
  `champ_gid` mediumint(8) NOT NULL DEFAULT '0',
  `champ_gtitle` varchar(40) NOT NULL DEFAULT '',
  `champ_mid` mediumint(8) NOT NULL DEFAULT '0',
  `champ_name` varchar(32) NOT NULL DEFAULT '',
  `champ_date` int(10) NOT NULL DEFAULT '0',
  `champ_score` float NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_games_list`
--

CREATE TABLE IF NOT EXISTS `ibf_games_list` (
  `gid` int(11) NOT NULL AUTO_INCREMENT,
  `gname` varchar(40) NOT NULL DEFAULT '',
  `gwords` text NOT NULL,
  `gcount` int(11) NOT NULL DEFAULT '0',
  `gtitle` varchar(40) NOT NULL DEFAULT '',
  `bgcolor` varchar(6) NOT NULL DEFAULT '000',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `gwidth` int(11) NOT NULL DEFAULT '400',
  `gheight` int(11) NOT NULL DEFAULT '400',
  `position` mediumint(8) NOT NULL DEFAULT '1',
  `gcat` int(2) NOT NULL DEFAULT '1',
  `object` text NOT NULL,
  `gkeys` text NOT NULL,
  `added` int(10) NOT NULL DEFAULT '0',
  `g_rating` tinyint(1) NOT NULL DEFAULT '0',
  `g_raters` text NOT NULL,
  `highscore_type` varchar(4) NOT NULL DEFAULT 'high',
  `ratio` int(8) NOT NULL DEFAULT '100000',
  `needed` mediumint(2) NOT NULL DEFAULT '1',
  UNIQUE KEY `gid` (`gid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='Game List' AUTO_INCREMENT=13 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_games_scores`
--

CREATE TABLE IF NOT EXISTS `ibf_games_scores` (
  `s_id` int(11) NOT NULL AUTO_INCREMENT,
  `mid` int(11) NOT NULL DEFAULT '0',
  `gid` int(11) NOT NULL DEFAULT '0',
  `name` text NOT NULL,
  `score` float NOT NULL DEFAULT '0',
  `ip` text NOT NULL,
  `comment` text NOT NULL,
  `datescored` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`s_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19513 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_games_settings`
--

CREATE TABLE IF NOT EXISTS `ibf_games_settings` (
  `arcade_status` tinyint(1) NOT NULL DEFAULT '1',
  `g_display_sort` varchar(15) NOT NULL DEFAULT '',
  `g_display_order` varchar(4) NOT NULL DEFAULT '',
  `scores_amount` mediumint(8) NOT NULL DEFAULT '10',
  `next_day` int(10) NOT NULL DEFAULT '0',
  `skin` tinyint(1) NOT NULL DEFAULT '0',
  `use_cats` tinyint(1) NOT NULL DEFAULT '0',
  `log` tinyint(1) NOT NULL DEFAULT '0',
  `score_type` char(3) NOT NULL DEFAULT '',
  `crown_type` tinyint(1) NOT NULL DEFAULT '0',
  `show_new` mediumint(8) NOT NULL DEFAULT '0',
  `show_new_frame` mediumint(5) NOT NULL DEFAULT '0',
  `show_active` text NOT NULL,
  `mod_notes` text NOT NULL,
  `most_users_on` mediumint(8) NOT NULL DEFAULT '0',
  `auto_prune` tinyint(1) NOT NULL DEFAULT '0',
  `auto_prune_time` mediumint(8) NOT NULL DEFAULT '0',
  `auto_prune_time2` mediumint(7) NOT NULL DEFAULT '0',
  `banned_ips` text NOT NULL,
  `games_pp` mediumint(8) NOT NULL DEFAULT '0',
  `allow_user_skin` tinyint(1) NOT NULL DEFAULT '0',
  `user_choices` text NOT NULL,
  `def_cat` mediumint(8) NOT NULL DEFAULT '1',
  `cats_per_tr` mediumint(8) NOT NULL DEFAULT '0',
  `show_crowns` tinyint(1) NOT NULL DEFAULT '1',
  `show_t_won` tinyint(1) NOT NULL DEFAULT '1',
  `score_sep` char(1) NOT NULL DEFAULT '0',
  `dec_amount` tinyint(2) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_groups`
--

CREATE TABLE IF NOT EXISTS `ibf_groups` (
  `g_id` int(3) unsigned NOT NULL AUTO_INCREMENT,
  `g_view_board` tinyint(1) DEFAULT NULL,
  `g_mem_info` tinyint(1) DEFAULT NULL,
  `g_other_topics` tinyint(1) DEFAULT NULL,
  `g_use_search` tinyint(1) DEFAULT NULL,
  `g_email_friend` tinyint(1) DEFAULT NULL,
  `g_invite_friend` tinyint(1) DEFAULT NULL,
  `g_edit_profile` tinyint(1) DEFAULT NULL,
  `g_post_new_topics` tinyint(1) DEFAULT NULL,
  `g_reply_own_topics` tinyint(1) DEFAULT NULL,
  `g_reply_other_topics` tinyint(1) DEFAULT NULL,
  `g_edit_posts` tinyint(1) DEFAULT NULL,
  `g_delete_own_posts` tinyint(1) DEFAULT NULL,
  `g_open_close_posts` tinyint(1) DEFAULT NULL,
  `g_delete_own_topics` tinyint(1) DEFAULT NULL,
  `g_post_polls` tinyint(1) DEFAULT NULL,
  `g_vote_polls` tinyint(1) DEFAULT NULL,
  `g_use_pm` tinyint(1) DEFAULT NULL,
  `g_is_supmod` tinyint(1) DEFAULT NULL,
  `g_access_cp` tinyint(1) DEFAULT NULL,
  `g_title` varchar(32) NOT NULL DEFAULT '',
  `g_can_remove` tinyint(1) DEFAULT NULL,
  `g_append_edit` tinyint(1) DEFAULT NULL,
  `g_access_offline` tinyint(1) DEFAULT NULL,
  `g_avoid_q` tinyint(1) DEFAULT NULL,
  `g_avoid_flood` tinyint(1) DEFAULT NULL,
  `g_icon` text NOT NULL,
  `g_attach_max` bigint(20) DEFAULT NULL,
  `g_avatar_upload` tinyint(1) DEFAULT '0',
  `g_calendar_post` tinyint(1) DEFAULT '0',
  `g_d_add_files` tinyint(1) DEFAULT NULL,
  `g_d_ibcode_files` tinyint(1) DEFAULT NULL,
  `g_d_html_files` tinyint(1) DEFAULT NULL,
  `g_do_download` tinyint(1) DEFAULT NULL,
  `g_d_edit_files` tinyint(1) DEFAULT NULL,
  `g_d_delete_files` tinyint(1) DEFAULT '0',
  `g_d_manage_files` tinyint(1) DEFAULT NULL,
  `g_d_allow_dl_offline` tinyint(1) DEFAULT NULL,
  `g_d_post_comments` tinyint(1) DEFAULT '0',
  `g_d_approve_down` tinyint(1) DEFAULT '0',
  `g_d_eofs` tinyint(1) DEFAULT '0',
  `g_d_optimize_db` tinyint(1) DEFAULT '0',
  `g_d_check_links` tinyint(1) DEFAULT '0',
  `g_d_check_topics` tinyint(1) DEFAULT '0',
  `g_d_max_dls` tinyint(4) DEFAULT '0',
  `g_d_manage_coms` tinyint(1) DEFAULT '0',
  `prefix` varchar(250) DEFAULT NULL,
  `suffix` varchar(250) DEFAULT NULL,
  `g_max_messages` int(5) DEFAULT '50',
  `g_max_mass_pm` int(5) DEFAULT '0',
  `g_search_flood` mediumint(6) DEFAULT '20',
  `g_edit_cutoff` int(10) DEFAULT '0',
  `g_promotion` varchar(10) DEFAULT '-1&-1',
  `g_post_closed` tinyint(1) DEFAULT '0',
  `g_perm_id` varchar(255) NOT NULL DEFAULT '',
  `g_photo_max_vars` varchar(200) DEFAULT '',
  `g_dohtml` tinyint(1) NOT NULL DEFAULT '0',
  `g_edit_topic` tinyint(1) NOT NULL DEFAULT '0',
  `g_email_limit` varchar(15) NOT NULL DEFAULT '10:15',
  `mod_wwo_g_online_info` tinyint(1) NOT NULL DEFAULT '0',
  `g_view_affiliate` tinyint(1) NOT NULL DEFAULT '1',
  `g_ad_boxes` varchar(255) NOT NULL DEFAULT 'ALL',
  `g_rate_members` tinyint(1) DEFAULT '1',
  `g_display` tinyint(3) NOT NULL DEFAULT '100',
  `g_fine_edit` tinyint(1) NOT NULL DEFAULT '0',
  `g_allow_inventoryedit` tinyint(1) NOT NULL DEFAULT '0',
  `g_discount` int(3) NOT NULL DEFAULT '0',
  `g_bypass_badwords` tinyint(1) NOT NULL DEFAULT '0',
  `g_can_msg_attach` tinyint(1) NOT NULL DEFAULT '0',
  `g_attach_per_post` int(10) NOT NULL DEFAULT '0',
  `g_access_store` tinyint(1) NOT NULL DEFAULT '1',
  `g_donate_points` tinyint(1) NOT NULL DEFAULT '1',
  `g_donate_items` tinyint(1) NOT NULL DEFAULT '1',
  `g_buyitems` tinyint(1) NOT NULL DEFAULT '1',
  `g_gain_points` tinyint(1) NOT NULL DEFAULT '1',
  `g_l_add_links` tinyint(1) NOT NULL DEFAULT '0',
  `g_l_mod_links` tinyint(1) NOT NULL DEFAULT '0',
  `g_l_add_comments` tinyint(1) NOT NULL DEFAULT '0',
  `g_l_access_close` tinyint(1) NOT NULL DEFAULT '0',
  `g_l_rate_links` tinyint(1) NOT NULL DEFAULT '0',
  `g_l_report_links` tinyint(1) NOT NULL DEFAULT '0',
  `g_hide_in_list` tinyint(1) NOT NULL DEFAULT '0',
  `g_hide_from_list` tinyint(1) NOT NULL DEFAULT '0',
  `g_view_dshoutbox` tinyint(1) DEFAULT '1',
  `g_post_dshoutbox` tinyint(1) DEFAULT '1',
  `g_dshoutbox_mod` tinyint(1) DEFAULT '0',
  `g_dshout_limit` int(11) DEFAULT '0',
  `g_dshouts_today` varchar(100) DEFAULT '0',
  `g_dshout_flood` int(11) DEFAULT NULL,
  `g_dshout_bypass` tinyint(1) DEFAULT '0',
  `g_dshout_saveload` tinyint(1) DEFAULT '1',
  `g_dshout_bwbypass` tinyint(1) DEFAULT '0',
  `g_dshout_editown` tinyint(1) DEFAULT '1',
  `g_dshout_deleteown` tinyint(1) DEFAULT '0',
  `arcade_access` tinyint(1) NOT NULL DEFAULT '1',
  `p_require` mediumint(8) NOT NULL DEFAULT '0',
  `max_play` mediumint(8) NOT NULL DEFAULT '0',
  `ppd_require` mediumint(8) NOT NULL DEFAULT '0',
  `g_mydir_access` tinyint(1) DEFAULT '1',
  `g_mydir_chmod` tinyint(1) DEFAULT '1',
  `g_mydir_download` tinyint(1) DEFAULT '1',
  `g_mydir_rename` tinyint(1) DEFAULT '1',
  `g_mydir_logactions` tinyint(1) DEFAULT '1',
  `g_mydir_maxdirsize` varchar(20) DEFAULT '{def}',
  `g_mydir_maxuploadsize` varchar(20) DEFAULT '{def}',
  `g_mydir_subdirs` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`g_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_iso_arcade_logs`
--

CREATE TABLE IF NOT EXISTS `ibf_iso_arcade_logs` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `date` int(10) NOT NULL DEFAULT '0',
  `mid` mediumint(8) NOT NULL DEFAULT '0',
  `gid` mediumint(8) NOT NULL DEFAULT '0',
  `times` tinyint(1) NOT NULL DEFAULT '0',
  `gain` tinyint(2) NOT NULL DEFAULT '0',
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5500 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_iso_arcade_times`
--

CREATE TABLE IF NOT EXISTS `ibf_iso_arcade_times` (
  `mid` mediumint(8) NOT NULL DEFAULT '0',
  `gid` mediumint(8) NOT NULL DEFAULT '0',
  `times` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_languages`
--

CREATE TABLE IF NOT EXISTS `ibf_languages` (
  `lid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `ldir` varchar(64) NOT NULL DEFAULT '',
  `lname` varchar(250) NOT NULL DEFAULT '',
  `lauthor` varchar(250) DEFAULT NULL,
  `lemail` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`lid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_links`
--

CREATE TABLE IF NOT EXISTS `ibf_links` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `cat` mediumint(8) NOT NULL DEFAULT '0',
  `link` varchar(75) NOT NULL DEFAULT '0',
  `href` varchar(255) NOT NULL DEFAULT '',
  `date` varchar(13) NOT NULL DEFAULT '0',
  `ldesc` mediumtext,
  `img` varchar(75) NOT NULL DEFAULT 'none.gif',
  `mem_id` mediumint(8) NOT NULL DEFAULT '0',
  `mem_name` varchar(75) NOT NULL DEFAULT 'Guest',
  `open` tinyint(1) NOT NULL DEFAULT '0',
  `hits` mediumint(8) NOT NULL DEFAULT '0',
  `rating` mediumint(8) NOT NULL DEFAULT '0',
  `is_affiliate` tinyint(1) NOT NULL DEFAULT '0',
  `hidden_by` mediumint(8) NOT NULL DEFAULT '0',
  `hidden_on` varchar(13) NOT NULL DEFAULT '0',
  `tot_comments` mediumint(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_links_cats`
--

CREATE TABLE IF NOT EXISTS `ibf_links_cats` (
  `cid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `sub` mediumint(8) NOT NULL DEFAULT '0',
  `cname` varchar(75) NOT NULL DEFAULT '0',
  `desc` tinytext NOT NULL,
  `open` tinyint(1) NOT NULL DEFAULT '0',
  `show_notes` tinyint(1) NOT NULL DEFAULT '0',
  `cnotes` mediumtext NOT NULL,
  `last_link` varchar(85) NOT NULL DEFAULT '0',
  `tot_links` mediumint(8) NOT NULL DEFAULT '0',
  `tot_hits` mediumint(8) NOT NULL DEFAULT '0',
  `last_link_date` varchar(13) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_links_comments`
--

CREATE TABLE IF NOT EXISTS `ibf_links_comments` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `link_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `mem_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `name` varchar(75) NOT NULL DEFAULT '',
  `date` varchar(13) NOT NULL DEFAULT '0',
  `comment` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_links_ratings`
--

CREATE TABLE IF NOT EXISTS `ibf_links_ratings` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `date` varchar(13) NOT NULL DEFAULT '0',
  `mem_id` mediumint(8) NOT NULL DEFAULT '0',
  `link_id` mediumint(8) NOT NULL DEFAULT '0',
  `rate` tinyint(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rate` (`rate`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_lots`
--

CREATE TABLE IF NOT EXISTS `ibf_lots` (
  `lotid` mediumint(4) NOT NULL DEFAULT '0',
  `mid` mediumint(8) NOT NULL DEFAULT '0',
  `lotnumber` tinyint(1) NOT NULL DEFAULT '0',
  `profit` mediumint(4) NOT NULL DEFAULT '0',
  `isdestroyed` tinyint(1) NOT NULL DEFAULT '0',
  `issecond` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_lots_rolls`
--

CREATE TABLE IF NOT EXISTS `ibf_lots_rolls` (
  `mid` mediumint(8) NOT NULL DEFAULT '0',
  `r_lotid` mediumint(2) NOT NULL DEFAULT '-1',
  `roll` tinyint(2) NOT NULL DEFAULT '0',
  `date` int(11) NOT NULL DEFAULT '0',
  `result` varchar(255) NOT NULL DEFAULT '',
  `r_code` char(1) NOT NULL DEFAULT '',
  KEY `date` (`date`),
  FULLTEXT KEY `result` (`result`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_lots_specials`
--

CREATE TABLE IF NOT EXISTS `ibf_lots_specials` (
  `s_mid` mediumint(8) DEFAULT NULL,
  `destruction` tinyint(1) NOT NULL DEFAULT '0',
  `freelot` tinyint(1) NOT NULL DEFAULT '0',
  `secondlot` tinyint(1) NOT NULL DEFAULT '0',
  `protection` tinyint(1) NOT NULL DEFAULT '0',
  `double` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_mail_error_logs`
--

CREATE TABLE IF NOT EXISTS `ibf_mail_error_logs` (
  `mlog_id` int(10) NOT NULL AUTO_INCREMENT,
  `mlog_date` int(10) NOT NULL DEFAULT '0',
  `mlog_to` varchar(250) NOT NULL DEFAULT '',
  `mlog_from` varchar(250) NOT NULL DEFAULT '',
  `mlog_subject` varchar(250) NOT NULL DEFAULT '',
  `mlog_content` varchar(250) NOT NULL DEFAULT '',
  `mlog_msg` text NOT NULL,
  `mlog_code` varchar(200) NOT NULL DEFAULT '',
  `mlog_smtp_msg` text NOT NULL,
  PRIMARY KEY (`mlog_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1917 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_mail_queue`
--

CREATE TABLE IF NOT EXISTS `ibf_mail_queue` (
  `mail_id` int(10) NOT NULL AUTO_INCREMENT,
  `mail_date` int(10) NOT NULL DEFAULT '0',
  `mail_to` varchar(255) NOT NULL DEFAULT '',
  `mail_from` varchar(255) NOT NULL DEFAULT '',
  `mail_subject` text NOT NULL,
  `mail_content` text NOT NULL,
  `mail_type` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`mail_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24342 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_mapteam_logs`
--

CREATE TABLE IF NOT EXISTS `ibf_mapteam_logs` (
  `id` smallint(4) NOT NULL AUTO_INCREMENT,
  `member_id` mediumint(8) NOT NULL DEFAULT '0',
  `member_name` varchar(32) NOT NULL DEFAULT '',
  `action` varchar(8) NOT NULL DEFAULT '',
  `object` mediumint(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5729 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_membermap_settings`
--

CREATE TABLE IF NOT EXISTS `ibf_membermap_settings` (
  `defaultmap` varchar(255) DEFAULT NULL,
  `greenpin` varchar(25) DEFAULT NULL,
  `redpin` varchar(25) DEFAULT NULL,
  `bluepin` varchar(25) DEFAULT NULL,
  `greypin` varchar(25) DEFAULT NULL,
  `cyanpin` varchar(25) DEFAULT NULL,
  `purplepin` varchar(25) DEFAULT NULL,
  `greenname` varchar(25) DEFAULT NULL,
  `redname` varchar(25) DEFAULT NULL,
  `bluename` varchar(25) DEFAULT NULL,
  `greyname` varchar(25) DEFAULT NULL,
  `cyanname` varchar(25) DEFAULT NULL,
  `purplename` varchar(25) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_members`
--

CREATE TABLE IF NOT EXISTS `ibf_members` (
  `id` mediumint(8) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `mgroup` smallint(3) NOT NULL DEFAULT '0',
  `legacy_password` varchar(32) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `joined` int(10) NOT NULL DEFAULT '0',
  `ip_address` varchar(16) NOT NULL DEFAULT '',
  `posts` mediumint(7) DEFAULT '0',
  `title` varchar(64) DEFAULT NULL,
  `allow_admin_mails` tinyint(1) DEFAULT NULL,
  `time_offset` varchar(10) DEFAULT NULL,
  `hide_email` varchar(8) DEFAULT NULL,
  `email_pm` tinyint(1) DEFAULT NULL,
  `email_full` tinyint(1) DEFAULT NULL,
  `skin` smallint(5) DEFAULT NULL,
  `warn_level` int(10) DEFAULT NULL,
  `warn_lastwarn` int(10) NOT NULL DEFAULT '0',
  `language` varchar(32) DEFAULT NULL,
  `last_post` int(10) DEFAULT NULL,
  `restrict_post` varchar(100) NOT NULL DEFAULT '0',
  `view_sigs` tinyint(1) DEFAULT '1',
  `view_img` tinyint(1) DEFAULT '1',
  `view_avs` tinyint(1) DEFAULT '1',
  `view_pop` tinyint(1) DEFAULT '1',
  `shout_style` char(1) NOT NULL DEFAULT 'n',
  `bday_day` int(2) DEFAULT NULL,
  `bday_month` int(2) DEFAULT NULL,
  `bday_year` int(4) DEFAULT NULL,
  `new_msg` tinyint(2) DEFAULT NULL,
  `msg_total` smallint(5) DEFAULT '0',
  `show_popup` tinyint(1) DEFAULT NULL,
  `misc` varchar(128) DEFAULT NULL,
  `last_visit` int(10) DEFAULT '0',
  `last_activity` int(10) DEFAULT '0',
  `dst_in_use` tinyint(1) DEFAULT '0',
  `view_prefs` varchar(64) DEFAULT '-1&-1',
  `coppa_user` tinyint(1) DEFAULT '0',
  `mod_posts` varchar(100) NOT NULL DEFAULT '0',
  `auto_track` varchar(50) DEFAULT '0',
  `org_perm_id` varchar(255) DEFAULT '',
  `org_supmod` tinyint(1) DEFAULT '0',
  `temp_ban` varchar(100) DEFAULT '0',
  `sub_end` int(10) NOT NULL DEFAULT '0',
  `files` smallint(5) DEFAULT '0',
  `downloads` smallint(5) DEFAULT '0',
  `points` bigint(11) NOT NULL DEFAULT '0',
  `deposited` int(16) NOT NULL DEFAULT '0',
  `auto_collect` tinyint(1) NOT NULL DEFAULT '0',
  `last_collect` varchar(30) NOT NULL DEFAULT '0/0/0',
  `extra_interest` int(3) NOT NULL DEFAULT '0',
  `storage_addon` int(15) NOT NULL DEFAULT '0',
  `name_prefix` text NOT NULL,
  `name_suffix` text NOT NULL,
  `login_anonymous` char(3) NOT NULL DEFAULT '0&0',
  `ignored_users` text NOT NULL,
  `mgroup_others` varchar(255) NOT NULL DEFAULT '',
  `member_login_key` varchar(32) NOT NULL DEFAULT '',
  `subs_pkg_chosen` smallint(3) NOT NULL DEFAULT '0',
  `creditcard` int(3) NOT NULL DEFAULT '0',
  `links` mediumint(8) NOT NULL DEFAULT '0',
  `sex` varchar(250) NOT NULL DEFAULT '',
  `country` varchar(250) NOT NULL DEFAULT '',
  `view_thx` tinyint(1) DEFAULT '1',
  `title_prefix` text NOT NULL,
  `title_suffix` text NOT NULL,
  `tickets` int(11) DEFAULT NULL,
  `use_dshoutbox` tinyint(1) DEFAULT '1',
  `dshoutbox_mod` tinyint(1) DEFAULT '0',
  `dshouts` mediumint(5) NOT NULL DEFAULT '0',
  `dshout_limit` int(11) DEFAULT '0',
  `dshouts_today` varchar(100) DEFAULT '0',
  `dshouts_alltime` int(11) NOT NULL DEFAULT '0',
  `dshout_saveload` tinyint(1) DEFAULT '1',
  `dshout_bwbypass` tinyint(1) DEFAULT '0',
  `dshout_editown` tinyint(1) NOT NULL DEFAULT '0',
  `dshout_deleteown` tinyint(1) DEFAULT '0',
  `last_shout_time` int(11) NOT NULL DEFAULT '0',
  `sb_shoutboxtype` char(1) DEFAULT 'D',
  `sb_showavatars` char(1) DEFAULT 'D',
  `sb_showshouttime` char(1) DEFAULT 'D',
  `sb_defaultcolor` varchar(100) DEFAULT 'D',
  `sb_refresh` varchar(100) DEFAULT 'D',
  `sb_showsmiliest` char(1) DEFAULT 'D',
  `sb_showtdshouters` char(1) DEFAULT 'D',
  `sb_showtpshouters` char(1) DEFAULT 'D',
  `sb_gsbtype` char(1) NOT NULL DEFAULT 'D',
  `sb_gsbrefresh` tinyint(1) NOT NULL DEFAULT '0',
  `sb_gsbstyle` char(1) NOT NULL DEFAULT 'N',
  `map` varchar(25) DEFAULT NULL,
  `map_location` varchar(25) DEFAULT NULL,
  `arcade_ban` tinyint(1) NOT NULL DEFAULT '0',
  `times_played` int(11) NOT NULL DEFAULT '0',
  `is_arcade_mod` tinyint(1) NOT NULL DEFAULT '0',
  `fav_games` text NOT NULL,
  `user_sort` varchar(15) NOT NULL DEFAULT '0',
  `user_order` varchar(4) NOT NULL DEFAULT '0',
  `user_g_pp` mediumint(8) NOT NULL DEFAULT '0',
  `user_s_pp` mediumint(8) NOT NULL DEFAULT '0',
  `def_g_cat` mediumint(8) NOT NULL DEFAULT '0',
  `game_skin` tinyint(1) NOT NULL DEFAULT '0',
  `arcade_mod_privs` text NOT NULL,
  `a_score` tinyint(1) NOT NULL DEFAULT '0',
  `a_send` tinyint(1) NOT NULL DEFAULT '0',
  `a_minerals` int(11) NOT NULL DEFAULT '0',
  `mydir_myid` varchar(32) DEFAULT '',
  `mydir_access` tinyint(1) DEFAULT '1',
  `mydir_maxdirsize` varchar(10) DEFAULT '{def}',
  `mydir_maxuploadsize` varchar(10) DEFAULT '{def}',
  `mydir_chmod` tinyint(1) DEFAULT '1',
  `mydir_download` tinyint(1) DEFAULT '1',
  `mydir_rename` tinyint(1) DEFAULT '1',
  `mydir_logactions` tinyint(1) DEFAULT '1',
  `mydir_custdirsize` varchar(20) DEFAULT '',
  `mydir_custuploadsize` varchar(20) DEFAULT '',
  `mydir_subdirs` tinyint(1) DEFAULT '1',
  `my_main_page` varchar(255) DEFAULT NULL,
  `space` int(10) NOT NULL DEFAULT '0',
  `menutoggle` tinyint(1) NOT NULL DEFAULT '1',
  `menubrowser` varchar(4) NOT NULL DEFAULT 'auto',
  `menulinks` varchar(100) NOT NULL DEFAULT '',
  `gavekarma` text,
  `karma` smallint(4) NOT NULL DEFAULT '0',
  `karmapoints` tinyint(5) NOT NULL DEFAULT '0',
  `secpass` varchar(32) NOT NULL DEFAULT '0',
  `squestion` text,
  `sanswer` text,
  `donations` mediumint(2) NOT NULL DEFAULT '0',
  `dlapprove` mediumint(9) NOT NULL DEFAULT '0',
  `munjpets` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `mgroup` (`mgroup`),
  KEY `bday_day` (`bday_day`),
  KEY `bday_month` (`bday_month`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_members_converge`
--

CREATE TABLE IF NOT EXISTS `ibf_members_converge` (
  `converge_id` int(10) NOT NULL AUTO_INCREMENT,
  `converge_email` varchar(250) NOT NULL DEFAULT '',
  `converge_joined` int(10) NOT NULL DEFAULT '0',
  `converge_pass_hash` varchar(32) NOT NULL DEFAULT '',
  `converge_pass_salt` varchar(5) NOT NULL DEFAULT '',
  PRIMARY KEY (`converge_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12624 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_member_extra`
--

CREATE TABLE IF NOT EXISTS `ibf_member_extra` (
  `id` mediumint(8) NOT NULL DEFAULT '0',
  `notes` text,
  `mem_notes` longtext,
  `links` text,
  `bio` text,
  `ta_size` char(3) DEFAULT NULL,
  `photo_type` varchar(10) DEFAULT '',
  `photo_location` varchar(255) DEFAULT '',
  `photo_dimensions` varchar(200) DEFAULT '',
  `aim_name` varchar(40) NOT NULL DEFAULT '',
  `icq_number` int(15) NOT NULL DEFAULT '0',
  `website` varchar(250) NOT NULL DEFAULT '',
  `yahoo` varchar(40) NOT NULL DEFAULT '',
  `interests` text NOT NULL,
  `msnname` varchar(200) NOT NULL DEFAULT '',
  `vdirs` text NOT NULL,
  `location` varchar(250) NOT NULL DEFAULT '',
  `signature` text NOT NULL,
  `avatar_location` varchar(128) NOT NULL DEFAULT '',
  `avatar_size` varchar(9) NOT NULL DEFAULT '',
  `avatar_type` varchar(15) NOT NULL DEFAULT 'local',
  `signature_location` varchar(128) NOT NULL DEFAULT '',
  `signature_size` varchar(9) NOT NULL DEFAULT '',
  `signature_type` varchar(15) NOT NULL DEFAULT 'local',
  `emo_fav` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_memrates`
--

CREATE TABLE IF NOT EXISTS `ibf_memrates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ratedid` int(11) NOT NULL DEFAULT '0',
  `mid` int(11) NOT NULL DEFAULT '0',
  `mname` varchar(100) NOT NULL DEFAULT '',
  `ip_address` varchar(20) NOT NULL DEFAULT '',
  `ratedate` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1255 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_memrates_master`
--

CREATE TABLE IF NOT EXISTS `ibf_memrates_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ratedid` int(11) NOT NULL DEFAULT '0',
  `mid` int(11) NOT NULL DEFAULT '0',
  `mname` varchar(100) NOT NULL DEFAULT '',
  `ip_address` varchar(20) NOT NULL DEFAULT '',
  `ratedate` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1255 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_message_text`
--

CREATE TABLE IF NOT EXISTS `ibf_message_text` (
  `msg_id` int(10) NOT NULL AUTO_INCREMENT,
  `msg_date` int(10) DEFAULT NULL,
  `msg_post` text,
  `msg_cc_users` text,
  `msg_sent_to_count` smallint(5) NOT NULL DEFAULT '0',
  `msg_deleted_count` smallint(5) NOT NULL DEFAULT '0',
  `msg_post_key` varchar(32) NOT NULL DEFAULT '0',
  `msg_author_id` mediumint(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`msg_id`),
  KEY `msg_date` (`msg_date`),
  KEY `msg_sent_to_count` (`msg_sent_to_count`),
  KEY `msg_deleted_count` (`msg_deleted_count`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=100486 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_message_topics`
--

CREATE TABLE IF NOT EXISTS `ibf_message_topics` (
  `mt_id` int(10) NOT NULL AUTO_INCREMENT,
  `mt_msg_id` int(10) NOT NULL DEFAULT '0',
  `mt_date` int(10) NOT NULL DEFAULT '0',
  `mt_title` varchar(255) NOT NULL DEFAULT '',
  `mt_from_id` mediumint(8) NOT NULL DEFAULT '0',
  `mt_to_id` mediumint(8) NOT NULL DEFAULT '0',
  `mt_owner_id` mediumint(8) NOT NULL DEFAULT '0',
  `mt_vid_folder` varchar(32) NOT NULL DEFAULT '',
  `mt_read` tinyint(1) NOT NULL DEFAULT '0',
  `mt_hasattach` smallint(5) NOT NULL DEFAULT '0',
  `mt_hide_cc` tinyint(1) DEFAULT '0',
  `mt_tracking` tinyint(1) DEFAULT '0',
  `mt_user_read` int(10) DEFAULT '0',
  PRIMARY KEY (`mt_id`),
  KEY `mt_from_id` (`mt_from_id`),
  KEY `mt_owner_id` (`mt_owner_id`,`mt_to_id`,`mt_vid_folder`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=151248 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_moderators`
--

CREATE TABLE IF NOT EXISTS `ibf_moderators` (
  `mid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `forum_id` int(5) NOT NULL DEFAULT '0',
  `member_name` varchar(32) NOT NULL DEFAULT '',
  `member_id` mediumint(8) NOT NULL DEFAULT '0',
  `edit_post` tinyint(1) DEFAULT NULL,
  `edit_topic` tinyint(1) DEFAULT NULL,
  `delete_post` tinyint(1) DEFAULT NULL,
  `delete_topic` tinyint(1) DEFAULT NULL,
  `view_ip` tinyint(1) DEFAULT NULL,
  `open_topic` tinyint(1) DEFAULT NULL,
  `close_topic` tinyint(1) DEFAULT NULL,
  `mass_move` tinyint(1) DEFAULT NULL,
  `mass_prune` tinyint(1) DEFAULT NULL,
  `move_topic` tinyint(1) DEFAULT NULL,
  `pin_topic` tinyint(1) DEFAULT NULL,
  `unpin_topic` tinyint(1) DEFAULT NULL,
  `post_q` tinyint(1) DEFAULT NULL,
  `topic_q` tinyint(1) DEFAULT NULL,
  `allow_warn` tinyint(1) DEFAULT NULL,
  `edit_user` tinyint(1) NOT NULL DEFAULT '0',
  `is_group` tinyint(1) DEFAULT '0',
  `group_id` smallint(3) DEFAULT NULL,
  `group_name` varchar(200) DEFAULT NULL,
  `split_merge` tinyint(1) DEFAULT '0',
  `can_mm` tinyint(1) NOT NULL DEFAULT '0',
  `clanfunctions` tinyint(1) NOT NULL DEFAULT '0',
  `permissions` tinyint(1) NOT NULL DEFAULT '0',
  `mask_id` tinyint(2) DEFAULT NULL,
  PRIMARY KEY (`mid`),
  KEY `forum_id` (`forum_id`),
  KEY `group_id` (`group_id`),
  KEY `member_id` (`member_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=440 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_moderator_logs`
--

CREATE TABLE IF NOT EXISTS `ibf_moderator_logs` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `forum_id` int(5) DEFAULT '0',
  `topic_id` int(10) NOT NULL DEFAULT '0',
  `post_id` int(10) DEFAULT NULL,
  `member_id` mediumint(8) NOT NULL DEFAULT '0',
  `member_name` varchar(32) NOT NULL DEFAULT '',
  `ip_address` varchar(16) NOT NULL DEFAULT '0',
  `http_referer` varchar(255) DEFAULT NULL,
  `ctime` int(10) DEFAULT NULL,
  `topic_title` varchar(128) DEFAULT NULL,
  `action` varchar(128) DEFAULT NULL,
  `query_string` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=31257 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_moose_boxes`
--

CREATE TABLE IF NOT EXISTS `ibf_moose_boxes` (
  `id` smallint(2) NOT NULL DEFAULT '0',
  `amt` mediumint(4) NOT NULL DEFAULT '0',
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_moose_boxplayers`
--

CREATE TABLE IF NOT EXISTS `ibf_moose_boxplayers` (
  `pid` mediumint(8) NOT NULL DEFAULT '0',
  `last` mediumint(3) NOT NULL DEFAULT '0',
  `new` tinyint(1) NOT NULL DEFAULT '0',
  `total` bigint(10) NOT NULL DEFAULT '0',
  `time` bigint(14) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_moose_lotto`
--

CREATE TABLE IF NOT EXISTS `ibf_moose_lotto` (
  `mid` smallint(4) unsigned DEFAULT '0',
  `tid` smallint(4) unsigned DEFAULT '0',
  KEY `tid` (`tid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_moose_lotto2`
--

CREATE TABLE IF NOT EXISTS `ibf_moose_lotto2` (
  `vari` text NOT NULL,
  `valu` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_moose_poker`
--

CREATE TABLE IF NOT EXISTS `ibf_moose_poker` (
  `player` mediumint(9) NOT NULL DEFAULT '0',
  `card1` smallint(2) NOT NULL DEFAULT '0',
  `card2` smallint(2) NOT NULL DEFAULT '0',
  `card3` smallint(2) NOT NULL DEFAULT '0',
  `card4` smallint(2) NOT NULL DEFAULT '0',
  `card5` smallint(2) NOT NULL DEFAULT '0',
  `card6` smallint(2) NOT NULL DEFAULT '0',
  `card7` smallint(2) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_mydir_logs`
--

CREATE TABLE IF NOT EXISTS `ibf_mydir_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `memid` int(11) NOT NULL DEFAULT '0',
  `member` varchar(255) NOT NULL DEFAULT '',
  `message` varchar(255) NOT NULL DEFAULT '--',
  `time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=37 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_mydir_mimetypes`
--

CREATE TABLE IF NOT EXISTS `ibf_mydir_mimetypes` (
  `m_id` int(10) NOT NULL AUTO_INCREMENT,
  `m_ext` varchar(18) NOT NULL DEFAULT '',
  `m_img` varchar(255) NOT NULL DEFAULT '',
  `m_mime` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`m_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=37 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_mymainpage`
--

CREATE TABLE IF NOT EXISTS `ibf_mymainpage` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `pname` varchar(255) NOT NULL DEFAULT '',
  `plink` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_pages`
--

CREATE TABLE IF NOT EXISTS `ibf_pages` (
  `id` int(3) unsigned NOT NULL AUTO_INCREMENT,
  `line_break` char(1) NOT NULL DEFAULT '1',
  `on_smile` char(1) NOT NULL DEFAULT '1',
  `alias` varchar(10) NOT NULL DEFAULT '',
  `name` varchar(30) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_pfields_content`
--

CREATE TABLE IF NOT EXISTS `ibf_pfields_content` (
  `member_id` mediumint(8) NOT NULL DEFAULT '0',
  `updated` int(10) DEFAULT '0',
  `field_5` text,
  `field_6` text,
  `field_8` text,
  PRIMARY KEY (`member_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_pfields_data`
--

CREATE TABLE IF NOT EXISTS `ibf_pfields_data` (
  `pf_id` smallint(5) NOT NULL AUTO_INCREMENT,
  `pf_title` varchar(250) NOT NULL DEFAULT '',
  `pf_desc` varchar(250) NOT NULL DEFAULT '',
  `pf_content` text NOT NULL,
  `pf_type` varchar(250) NOT NULL DEFAULT '',
  `pf_not_null` tinyint(1) NOT NULL DEFAULT '0',
  `pf_member_hide` tinyint(1) NOT NULL DEFAULT '0',
  `pf_max_input` smallint(6) NOT NULL DEFAULT '0',
  `pf_member_edit` tinyint(1) NOT NULL DEFAULT '0',
  `pf_position` smallint(6) NOT NULL DEFAULT '0',
  `pf_show_on_reg` tinyint(1) NOT NULL DEFAULT '0',
  `pf_input_format` text NOT NULL,
  `pf_admin_only` tinyint(1) NOT NULL DEFAULT '0',
  `pf_topic_format` text NOT NULL,
  PRIMARY KEY (`pf_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_polls`
--

CREATE TABLE IF NOT EXISTS `ibf_polls` (
  `pid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `tid` int(10) NOT NULL DEFAULT '0',
  `start_date` int(10) DEFAULT NULL,
  `choices` text,
  `starter_id` mediumint(8) NOT NULL DEFAULT '0',
  `votes` smallint(5) NOT NULL DEFAULT '0',
  `forum_id` smallint(5) NOT NULL DEFAULT '0',
  `poll_question` varchar(255) DEFAULT NULL,
  `is_multi_poll` tinyint(1) NOT NULL DEFAULT '0',
  `multi_poll_min` tinyint(2) NOT NULL DEFAULT '0',
  `multi_poll_max` tinyint(2) NOT NULL DEFAULT '0',
  `is_weighted_poll` tinyint(1) NOT NULL DEFAULT '0',
  `weighted_poll_places` tinyint(2) NOT NULL DEFAULT '0',
  `poll_active` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2348 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_poll_results`
--

CREATE TABLE IF NOT EXISTS `ibf_poll_results` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '',
  `primary_3` int(4) NOT NULL DEFAULT '0',
  `secondary_2` int(4) NOT NULL DEFAULT '0',
  `tertiary_1` int(4) NOT NULL DEFAULT '0',
  `total_votes` int(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_poll_voters`
--

CREATE TABLE IF NOT EXISTS `ibf_poll_voters` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '',
  `primary_3` int(4) NOT NULL DEFAULT '0',
  `secondary_2` int(4) NOT NULL DEFAULT '0',
  `tertiary_1` int(4) NOT NULL DEFAULT '0',
  `ip_address` varchar(16) NOT NULL DEFAULT '',
  `referral` varchar(16) NOT NULL DEFAULT '',
  PRIMARY KEY (`name`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `ip_address` (`ip_address`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=93 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_portal_box`
--

CREATE TABLE IF NOT EXISTS `ibf_portal_box` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL DEFAULT '',
  `content` mediumtext NOT NULL,
  `align` varchar(10) NOT NULL DEFAULT '',
  `guest_view` char(1) NOT NULL DEFAULT '',
  `hidden` tinyint(4) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '0',
  `type` varchar(80) NOT NULL DEFAULT '',
  `site` varchar(200) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_portal_files`
--

CREATE TABLE IF NOT EXISTS `ibf_portal_files` (
  `id` tinyint(4) NOT NULL DEFAULT '0',
  `file_id` mediumint(8) NOT NULL DEFAULT '0',
  `about` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_portal_sites`
--

CREATE TABLE IF NOT EXISTS `ibf_portal_sites` (
  `name` varchar(100) NOT NULL DEFAULT '',
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `leftw` varchar(10) NOT NULL DEFAULT '20%',
  `middlew` varchar(10) NOT NULL DEFAULT '60%',
  `rightw` varchar(10) NOT NULL DEFAULT '20%',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_posts`
--

CREATE TABLE IF NOT EXISTS `ibf_posts` (
  `pid` int(10) NOT NULL AUTO_INCREMENT,
  `append_edit` tinyint(1) DEFAULT '0',
  `edit_time` int(10) DEFAULT NULL,
  `author_id` mediumint(8) NOT NULL DEFAULT '0',
  `author_name` varchar(32) DEFAULT NULL,
  `use_sig` tinyint(1) NOT NULL DEFAULT '0',
  `use_emo` tinyint(1) NOT NULL DEFAULT '0',
  `ip_address` varchar(16) NOT NULL DEFAULT '',
  `post_date` int(10) DEFAULT NULL,
  `icon_id` smallint(3) DEFAULT NULL,
  `post` text,
  `queued` tinyint(1) NOT NULL DEFAULT '0',
  `topic_id` int(10) NOT NULL DEFAULT '0',
  `post_title` varchar(255) DEFAULT NULL,
  `new_topic` tinyint(1) DEFAULT '0',
  `edit_name` varchar(255) DEFAULT NULL,
  `post_parent` int(10) NOT NULL DEFAULT '0',
  `post_key` varchar(32) NOT NULL DEFAULT '0',
  `post_htmlstate` smallint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pid`),
  KEY `topic_id` (`topic_id`,`queued`,`pid`),
  KEY `author_id` (`author_id`,`topic_id`),
  KEY `post_date` (`post_date`),
  FULLTEXT KEY `post` (`post`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=625585 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_quotes`
--

CREATE TABLE IF NOT EXISTS `ibf_quotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quote` text NOT NULL,
  `accepted` char(1) NOT NULL DEFAULT 'N',
  `num` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=62 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_quotes_logs`
--

CREATE TABLE IF NOT EXISTS `ibf_quotes_logs` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `quote` text NOT NULL,
  `ip` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=62 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_races`
--

CREATE TABLE IF NOT EXISTS `ibf_races` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `race` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_raffle`
--

CREATE TABLE IF NOT EXISTS `ibf_raffle` (
  `drawday` date DEFAULT NULL,
  `winnerid` varchar(255) DEFAULT NULL,
  `pot` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_raffle_settings`
--

CREATE TABLE IF NOT EXISTS `ibf_raffle_settings` (
  `cost` varchar(10) DEFAULT NULL,
  `topcount` int(11) DEFAULT NULL,
  `timetodraw` varchar(255) DEFAULT NULL,
  `rafflename` varchar(255) DEFAULT NULL,
  `maxticket` int(11) DEFAULT NULL,
  `startwith` int(11) DEFAULT NULL,
  `daystodraw` varchar(255) DEFAULT NULL,
  `added` int(11) DEFAULT NULL,
  `allowed_groups` varchar(100) DEFAULT NULL,
  `multiplier` varchar(4) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_reg_antispam`
--

CREATE TABLE IF NOT EXISTS `ibf_reg_antispam` (
  `regid` varchar(32) NOT NULL DEFAULT '',
  `regcode` varchar(8) NOT NULL DEFAULT '',
  `ip_address` varchar(32) DEFAULT NULL,
  `ctime` int(10) DEFAULT NULL,
  PRIMARY KEY (`regid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_search_results`
--

CREATE TABLE IF NOT EXISTS `ibf_search_results` (
  `id` varchar(32) NOT NULL DEFAULT '',
  `topic_id` text NOT NULL,
  `search_date` int(12) NOT NULL DEFAULT '0',
  `topic_max` int(3) NOT NULL DEFAULT '0',
  `sort_key` varchar(32) NOT NULL DEFAULT 'last_post',
  `sort_order` varchar(4) NOT NULL DEFAULT 'desc',
  `member_id` mediumint(10) DEFAULT '0',
  `ip_address` varchar(64) DEFAULT NULL,
  `post_id` text,
  `post_max` int(10) NOT NULL DEFAULT '0',
  `query_cache` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_sessions`
--

CREATE TABLE IF NOT EXISTS `ibf_sessions` (
  `id` varchar(32) NOT NULL DEFAULT '0',
  `member_name` varchar(64) DEFAULT NULL,
  `member_id` mediumint(8) NOT NULL DEFAULT '0',
  `ip_address` varchar(16) DEFAULT NULL,
  `browser` varchar(64) DEFAULT NULL,
  `running_time` int(10) DEFAULT NULL,
  `login_type` tinyint(1) DEFAULT NULL,
  `location` varchar(40) DEFAULT NULL,
  `member_group` smallint(3) DEFAULT NULL,
  `in_forum` smallint(5) NOT NULL DEFAULT '0',
  `in_topic` int(10) DEFAULT NULL,
  `member_icon` varchar(48) DEFAULT 'no_icon.gif',
  `in_down` int(10) NOT NULL DEFAULT '0',
  `in_downcat` int(10) NOT NULL DEFAULT '0',
  `in_error` tinyint(1) NOT NULL DEFAULT '0',
  `in_dldo` varchar(30) DEFAULT NULL,
  `in_dlcat` varchar(30) DEFAULT NULL,
  `in_dlfile` mediumint(8) DEFAULT NULL,
  `in_do` varchar(30) DEFAULT NULL,
  `in_cat` varchar(30) DEFAULT NULL,
  `in_id` mediumint(8) DEFAULT NULL,
  `parsed_browser` varchar(50) NOT NULL DEFAULT 'none',
  `in_game` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `in_topic` (`in_topic`),
  KEY `in_forum` (`in_forum`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_shoutbox`
--

CREATE TABLE IF NOT EXISTS `ibf_shoutbox` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `uid` int(11) NOT NULL DEFAULT '0',
  `mgroup` int(11) NOT NULL DEFAULT '0',
  `shout` longtext NOT NULL,
  `color` varchar(100) NOT NULL DEFAULT '',
  `date` varchar(255) NOT NULL DEFAULT '',
  `time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=263 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_shoutbox_badwords`
--

CREATE TABLE IF NOT EXISTS `ibf_shoutbox_badwords` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bword` varchar(255) NOT NULL DEFAULT '',
  `switch` varchar(255) DEFAULT NULL,
  `exact` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_shoutbox_colors`
--

CREATE TABLE IF NOT EXISTS `ibf_shoutbox_colors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `color` varchar(255) NOT NULL DEFAULT '',
  `cname` varchar(255) DEFAULT NULL,
  `corder` int(5) DEFAULT NULL,
  `visible` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_shoutbox_exports`
--

CREATE TABLE IF NOT EXISTS `ibf_shoutbox_exports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL DEFAULT '',
  `filesize` int(11) DEFAULT NULL,
  `type` varchar(4) NOT NULL DEFAULT '',
  `date` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_shoutbox_ignored`
--

CREATE TABLE IF NOT EXISTS `ibf_shoutbox_ignored` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mid` int(11) NOT NULL DEFAULT '0',
  `uid` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `grp` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=125 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_shoutbox_savedshouts`
--

CREATE TABLE IF NOT EXISTS `ibf_shoutbox_savedshouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shouter` varchar(255) NOT NULL DEFAULT '',
  `mid` int(11) NOT NULL DEFAULT '0',
  `mgroup` int(11) NOT NULL DEFAULT '0',
  `shout` longtext NOT NULL,
  `color` varchar(255) NOT NULL DEFAULT '',
  `shouttime` int(11) NOT NULL DEFAULT '0',
  `last_edit` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=109 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_shoutbox_settings`
--

CREATE TABLE IF NOT EXISTS `ibf_shoutbox_settings` (
  `set_id` int(5) NOT NULL AUTO_INCREMENT,
  `set_group` int(3) NOT NULL DEFAULT '0',
  `set_name` varchar(255) NOT NULL DEFAULT '',
  `set_title` varchar(255) NOT NULL DEFAULT '',
  `set_desc` text NOT NULL,
  `set_value` text,
  `set_default` text NOT NULL,
  `set_type` char(2) NOT NULL DEFAULT '',
  `set_order` int(3) NOT NULL DEFAULT '0',
  `set_options` text,
  `set_cols` tinyint(3) DEFAULT NULL,
  `set_rows` tinyint(3) DEFAULT NULL,
  PRIMARY KEY (`set_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_shoutbox_stats`
--

CREATE TABLE IF NOT EXISTS `ibf_shoutbox_stats` (
  `totalshouts` int(11) DEFAULT NULL,
  `shouts_today` int(11) DEFAULT NULL,
  `shouts_alltime` int(11) DEFAULT NULL,
  `lastshout_date` varchar(50) DEFAULT NULL,
  `sbox_tbadwords` int(11) DEFAULT NULL,
  `sbox_tcolors` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_skin_macro`
--

CREATE TABLE IF NOT EXISTS `ibf_skin_macro` (
  `macro_id` smallint(3) NOT NULL AUTO_INCREMENT,
  `macro_value` varchar(200) DEFAULT NULL,
  `macro_replace` text,
  `macro_can_remove` tinyint(1) DEFAULT '0',
  `macro_set` smallint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`macro_id`),
  KEY `macro_set` (`macro_set`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=720 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_skin_sets`
--

CREATE TABLE IF NOT EXISTS `ibf_skin_sets` (
  `set_skin_set_id` int(10) NOT NULL AUTO_INCREMENT,
  `set_name` varchar(150) NOT NULL DEFAULT '',
  `set_image_dir` varchar(200) NOT NULL DEFAULT '',
  `set_hidden` tinyint(1) NOT NULL DEFAULT '0',
  `set_default` tinyint(1) NOT NULL DEFAULT '0',
  `set_css_method` varchar(100) NOT NULL DEFAULT 'inline',
  `set_skin_set_parent` smallint(5) NOT NULL DEFAULT '-1',
  `set_author_email` varchar(255) NOT NULL DEFAULT '',
  `set_author_name` varchar(255) NOT NULL DEFAULT '',
  `set_author_url` varchar(255) NOT NULL DEFAULT '',
  `set_css` mediumtext NOT NULL,
  `set_wrapper` mediumtext NOT NULL,
  `set_css_updated` int(10) NOT NULL DEFAULT '0',
  `set_cache_css` mediumtext NOT NULL,
  `set_cache_macro` mediumtext NOT NULL,
  `set_cache_wrapper` mediumtext NOT NULL,
  `set_emoticon_folder` varchar(60) NOT NULL DEFAULT 'default',
  PRIMARY KEY (`set_skin_set_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_skin_templates`
--

CREATE TABLE IF NOT EXISTS `ibf_skin_templates` (
  `suid` int(10) NOT NULL AUTO_INCREMENT,
  `set_id` int(10) NOT NULL DEFAULT '0',
  `group_name` varchar(255) NOT NULL DEFAULT '',
  `section_content` mediumtext,
  `func_name` varchar(255) DEFAULT NULL,
  `func_data` text,
  `updated` int(10) DEFAULT NULL,
  `can_remove` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`suid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=43617 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_skin_templates_cache`
--

CREATE TABLE IF NOT EXISTS `ibf_skin_templates_cache` (
  `template_id` varchar(32) NOT NULL DEFAULT '',
  `template_group_name` varchar(255) NOT NULL DEFAULT '',
  `template_group_content` mediumtext NOT NULL,
  `template_set_id` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`template_id`),
  KEY `template_set_id` (`template_set_id`),
  KEY `template_group_name` (`template_group_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_spider_logs`
--

CREATE TABLE IF NOT EXISTS `ibf_spider_logs` (
  `sid` int(10) NOT NULL AUTO_INCREMENT,
  `bot` varchar(255) NOT NULL DEFAULT '',
  `query_string` text NOT NULL,
  `entry_date` int(10) NOT NULL DEFAULT '0',
  `ip_address` varchar(16) NOT NULL DEFAULT '',
  `in_down` int(10) NOT NULL DEFAULT '0',
  `in_downcat` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`sid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=459 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_splash`
--

CREATE TABLE IF NOT EXISTS `ibf_splash` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `value` blob,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_statistics_data`
--

CREATE TABLE IF NOT EXISTS `ibf_statistics_data` (
  `id` tinyint(2) NOT NULL AUTO_INCREMENT,
  `enable` tinyint(1) NOT NULL DEFAULT '1',
  `title` varchar(64) NOT NULL DEFAULT '',
  `link` text NOT NULL,
  `data` text NOT NULL,
  `updated` int(16) NOT NULL DEFAULT '0',
  `groupid` tinyint(1) NOT NULL DEFAULT '0',
  `qdatatype` varchar(16) NOT NULL DEFAULT '',
  `qquery` varchar(255) NOT NULL DEFAULT '',
  `qlimit` tinyint(2) NOT NULL DEFAULT '10',
  `qordering` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  FULLTEXT KEY `data` (`link`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_statistics_groups`
--

CREATE TABLE IF NOT EXISTS `ibf_statistics_groups` (
  `gid` mediumint(2) NOT NULL DEFAULT '0',
  `g_order` tinyint(2) NOT NULL DEFAULT '0',
  `g_name` varchar(64) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_store_categories`
--

CREATE TABLE IF NOT EXISTS `ibf_store_categories` (
  `catid` int(9) NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(255) NOT NULL DEFAULT '',
  `cat_desc` text NOT NULL,
  `cat_stock` int(16) NOT NULL DEFAULT '0',
  `cat_showside` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`catid`),
  KEY `catid` (`catid`),
  KEY `cat_name` (`cat_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_store_creditcards`
--

CREATE TABLE IF NOT EXISTS `ibf_store_creditcards` (
  `cid` int(3) NOT NULL AUTO_INCREMENT,
  `cname` varchar(255) NOT NULL DEFAULT '',
  `cdesc` text NOT NULL,
  `cprice` int(16) NOT NULL DEFAULT '0',
  `cinterest` int(3) NOT NULL DEFAULT '2',
  `cfee` int(3) NOT NULL DEFAULT '10',
  `cgroups` text NOT NULL,
  PRIMARY KEY (`cid`),
  KEY `cname` (`cname`,`cprice`),
  KEY `cid` (`cid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_store_inventory`
--

CREATE TABLE IF NOT EXISTS `ibf_store_inventory` (
  `i_id` int(9) NOT NULL AUTO_INCREMENT,
  `owner_id` int(9) NOT NULL DEFAULT '0',
  `item_id` int(9) NOT NULL DEFAULT '0',
  `price_paid` int(16) NOT NULL DEFAULT '0',
  PRIMARY KEY (`i_id`),
  KEY `i_id` (`i_id`),
  KEY `owner_id` (`owner_id`),
  KEY `item_id` (`item_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3540 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_store_logs`
--

CREATE TABLE IF NOT EXISTS `ibf_store_logs` (
  `lid` int(9) NOT NULL AUTO_INCREMENT,
  `lmessage` text NOT NULL,
  `luserid` int(16) NOT NULL DEFAULT '0',
  `ltype` varchar(255) NOT NULL DEFAULT '',
  `ltime` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10066 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_store_modlogs`
--

CREATE TABLE IF NOT EXISTS `ibf_store_modlogs` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL DEFAULT '0',
  `reson` text NOT NULL,
  `user_reson` text NOT NULL,
  `type` varchar(255) NOT NULL DEFAULT '',
  `time` int(15) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=37 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_store_quizinfo`
--

CREATE TABLE IF NOT EXISTS `ibf_store_quizinfo` (
  `q_id` int(9) NOT NULL AUTO_INCREMENT,
  `quizname` varchar(255) NOT NULL DEFAULT '',
  `quizdesc` text NOT NULL,
  `percent_needed` int(3) NOT NULL DEFAULT '0',
  `amount_won` int(9) NOT NULL DEFAULT '0',
  `started_on` int(14) NOT NULL DEFAULT '0',
  `run_for` int(15) NOT NULL DEFAULT '0',
  `let_only` int(9) NOT NULL DEFAULT '0',
  `quiz_status` varchar(6) NOT NULL DEFAULT 'OPEN',
  `timeout` int(9) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '1',
  `quiz_items` text NOT NULL,
  PRIMARY KEY (`q_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_store_quizs`
--

CREATE TABLE IF NOT EXISTS `ibf_store_quizs` (
  `mid` int(15) NOT NULL AUTO_INCREMENT,
  `quiz_id` int(9) NOT NULL DEFAULT '0',
  `question` text NOT NULL,
  `anwser` text NOT NULL,
  `type` varchar(11) NOT NULL DEFAULT 'single',
  PRIMARY KEY (`mid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_store_quizwinners`
--

CREATE TABLE IF NOT EXISTS `ibf_store_quizwinners` (
  `quiz_id` int(9) NOT NULL DEFAULT '0',
  `memberid` int(9) NOT NULL DEFAULT '0',
  `amount_right` int(9) NOT NULL DEFAULT '0',
  `time_took` int(9) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_store_shopstock`
--

CREATE TABLE IF NOT EXISTS `ibf_store_shopstock` (
  `id` int(16) NOT NULL AUTO_INCREMENT,
  `item_name` varchar(255) NOT NULL DEFAULT '',
  `icon` varchar(255) NOT NULL DEFAULT 'none.gif',
  `item_desc` text NOT NULL,
  `sell_price` int(16) NOT NULL DEFAULT '0',
  `module` tinytext NOT NULL,
  `stock` int(9) NOT NULL DEFAULT '0',
  `category` int(5) NOT NULL DEFAULT '0',
  `is_hidden` tinyint(1) NOT NULL DEFAULT '0',
  `settings` longtext NOT NULL,
  `last_restock` int(13) NOT NULL DEFAULT '0',
  `restock_amount` int(12) NOT NULL DEFAULT '0',
  `restock_time` varchar(255) NOT NULL DEFAULT '0_m',
  `restock_at` int(11) NOT NULL DEFAULT '0',
  `restock_untill` int(11) NOT NULL DEFAULT '0',
  `can_resell` tinyint(1) NOT NULL DEFAULT '1',
  `can_delete` tinyint(1) NOT NULL DEFAULT '1',
  `can_trade` tinyint(1) NOT NULL DEFAULT '1',
  `item_limit` int(9) NOT NULL DEFAULT '0',
  `buyban_groups` varchar(255) NOT NULL DEFAULT '*',
  `protect_groups` varchar(255) NOT NULL DEFAULT '*',
  PRIMARY KEY (`id`),
  KEY `item_name` (`item_name`),
  KEY `sell_price` (`sell_price`),
  KEY `stock` (`stock`),
  KEY `category` (`category`),
  KEY `is_hidden` (`is_hidden`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_subscriptions`
--

CREATE TABLE IF NOT EXISTS `ibf_subscriptions` (
  `sub_id` smallint(5) NOT NULL AUTO_INCREMENT,
  `sub_title` varchar(250) NOT NULL DEFAULT '',
  `sub_desc` text,
  `sub_new_group` mediumint(8) NOT NULL DEFAULT '0',
  `sub_length` smallint(5) NOT NULL DEFAULT '1',
  `sub_unit` char(2) NOT NULL DEFAULT 'm',
  `sub_cost` decimal(10,2) NOT NULL DEFAULT '0.00',
  `sub_run_module` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`sub_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_subscription_currency`
--

CREATE TABLE IF NOT EXISTS `ibf_subscription_currency` (
  `subcurrency_code` varchar(10) NOT NULL DEFAULT '',
  `subcurrency_desc` varchar(250) NOT NULL DEFAULT '',
  `subcurrency_exchange` decimal(10,8) NOT NULL DEFAULT '0.00000000',
  `subcurrency_default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`subcurrency_code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_subscription_extra`
--

CREATE TABLE IF NOT EXISTS `ibf_subscription_extra` (
  `subextra_id` smallint(5) NOT NULL AUTO_INCREMENT,
  `subextra_sub_id` smallint(5) NOT NULL DEFAULT '0',
  `subextra_method_id` smallint(5) NOT NULL DEFAULT '0',
  `subextra_product_id` varchar(250) NOT NULL DEFAULT '0',
  `subextra_can_upgrade` tinyint(1) NOT NULL DEFAULT '0',
  `subextra_recurring` tinyint(1) NOT NULL DEFAULT '0',
  `subextra_custom_1` text,
  `subextra_custom_2` text,
  `subextra_custom_3` text,
  `subextra_custom_4` text,
  `subextra_custom_5` text,
  PRIMARY KEY (`subextra_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_subscription_logs`
--

CREATE TABLE IF NOT EXISTS `ibf_subscription_logs` (
  `sublog_id` int(10) NOT NULL AUTO_INCREMENT,
  `sublog_date` int(10) NOT NULL DEFAULT '0',
  `sublog_member_id` mediumint(8) NOT NULL DEFAULT '0',
  `sublog_transid` int(10) NOT NULL DEFAULT '0',
  `sublog_ipaddress` varchar(16) NOT NULL DEFAULT '',
  `sublog_data` text,
  `sublog_postdata` text,
  PRIMARY KEY (`sublog_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_subscription_methods`
--

CREATE TABLE IF NOT EXISTS `ibf_subscription_methods` (
  `submethod_id` smallint(5) NOT NULL AUTO_INCREMENT,
  `submethod_title` varchar(250) NOT NULL DEFAULT '',
  `submethod_name` varchar(20) NOT NULL DEFAULT '',
  `submethod_email` varchar(250) NOT NULL DEFAULT '',
  `submethod_sid` text,
  `submethod_custom_1` text,
  `submethod_custom_2` text,
  `submethod_custom_3` text,
  `submethod_custom_4` text,
  `submethod_custom_5` text,
  `submethod_is_cc` tinyint(1) NOT NULL DEFAULT '0',
  `submethod_is_auto` tinyint(1) NOT NULL DEFAULT '0',
  `submethod_desc` text,
  `submethod_logo` text,
  `submethod_active` tinyint(1) NOT NULL DEFAULT '0',
  `submethod_use_currency` varchar(10) NOT NULL DEFAULT 'USD',
  PRIMARY KEY (`submethod_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_subscription_trans`
--

CREATE TABLE IF NOT EXISTS `ibf_subscription_trans` (
  `subtrans_id` int(10) NOT NULL AUTO_INCREMENT,
  `subtrans_sub_id` smallint(5) NOT NULL DEFAULT '0',
  `subtrans_member_id` mediumint(8) NOT NULL DEFAULT '0',
  `subtrans_old_group` smallint(5) NOT NULL DEFAULT '0',
  `subtrans_paid` decimal(10,2) NOT NULL DEFAULT '0.00',
  `subtrans_cumulative` decimal(10,2) NOT NULL DEFAULT '0.00',
  `subtrans_method` varchar(20) NOT NULL DEFAULT '',
  `subtrans_start_date` int(11) NOT NULL DEFAULT '0',
  `subtrans_end_date` int(11) NOT NULL DEFAULT '0',
  `subtrans_state` varchar(200) NOT NULL DEFAULT '',
  `subtrans_trxid` varchar(200) NOT NULL DEFAULT '',
  `subtrans_subscrid` varchar(200) NOT NULL DEFAULT '',
  `subtrans_currency` varchar(10) NOT NULL DEFAULT 'USD',
  PRIMARY KEY (`subtrans_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_task_logs`
--

CREATE TABLE IF NOT EXISTS `ibf_task_logs` (
  `log_id` int(10) NOT NULL AUTO_INCREMENT,
  `log_title` varchar(255) NOT NULL DEFAULT '',
  `log_date` int(10) NOT NULL DEFAULT '0',
  `log_ip` varchar(16) NOT NULL DEFAULT '0',
  `log_desc` text NOT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=36184 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_task_manager`
--

CREATE TABLE IF NOT EXISTS `ibf_task_manager` (
  `task_id` int(10) NOT NULL AUTO_INCREMENT,
  `task_title` varchar(255) NOT NULL DEFAULT '',
  `task_file` varchar(255) NOT NULL DEFAULT '',
  `task_next_run` int(10) NOT NULL DEFAULT '0',
  `task_week_day` tinyint(1) NOT NULL DEFAULT '-1',
  `task_month_day` smallint(2) NOT NULL DEFAULT '-1',
  `task_hour` smallint(2) NOT NULL DEFAULT '-1',
  `task_minute` smallint(2) NOT NULL DEFAULT '-1',
  `task_cronkey` varchar(32) NOT NULL DEFAULT '',
  `task_log` tinyint(1) NOT NULL DEFAULT '0',
  `task_description` text NOT NULL,
  `task_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `task_key` varchar(30) NOT NULL DEFAULT '',
  `task_safemode` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`task_id`),
  KEY `task_next_run` (`task_next_run`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_titles`
--

CREATE TABLE IF NOT EXISTS `ibf_titles` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `posts` int(10) DEFAULT NULL,
  `title` varchar(128) DEFAULT NULL,
  `pips` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_topics`
--

CREATE TABLE IF NOT EXISTS `ibf_topics` (
  `tid` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(70) NOT NULL DEFAULT '',
  `description` varchar(70) DEFAULT NULL,
  `state` varchar(8) DEFAULT NULL,
  `posts` int(10) DEFAULT NULL,
  `starter_id` mediumint(8) NOT NULL DEFAULT '0',
  `start_date` int(10) DEFAULT NULL,
  `last_poster_id` mediumint(8) NOT NULL DEFAULT '0',
  `last_post` int(10) DEFAULT NULL,
  `icon_id` tinyint(2) DEFAULT NULL,
  `starter_name` varchar(32) DEFAULT NULL,
  `last_poster_name` varchar(32) DEFAULT NULL,
  `poll_state` varchar(8) DEFAULT NULL,
  `last_vote` int(10) DEFAULT NULL,
  `views` int(10) DEFAULT NULL,
  `forum_id` smallint(5) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `author_mode` tinyint(1) DEFAULT NULL,
  `pinned` tinyint(1) NOT NULL DEFAULT '0',
  `moved_to` varchar(64) DEFAULT NULL,
  `rating` text,
  `total_votes` int(5) NOT NULL DEFAULT '0',
  `topic_hasattach` smallint(5) NOT NULL DEFAULT '0',
  `topic_firstpost` int(10) NOT NULL DEFAULT '0',
  `topic_queuedposts` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tid`),
  KEY `last_post` (`last_post`),
  KEY `forum_id` (`forum_id`,`approved`,`pinned`),
  KEY `topic_firstpost` (`topic_firstpost`),
  FULLTEXT KEY `title` (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=38811 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_topics_read`
--

CREATE TABLE IF NOT EXISTS `ibf_topics_read` (
  `read_tid` int(10) NOT NULL DEFAULT '0',
  `read_mid` mediumint(8) NOT NULL DEFAULT '0',
  `read_date` int(10) NOT NULL DEFAULT '0',
  UNIQUE KEY `read_tid_mid` (`read_tid`,`read_mid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_topic_mmod`
--

CREATE TABLE IF NOT EXISTS `ibf_topic_mmod` (
  `mm_id` smallint(5) NOT NULL AUTO_INCREMENT,
  `mm_title` varchar(250) NOT NULL DEFAULT '',
  `mm_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `topic_state` varchar(10) NOT NULL DEFAULT 'leave',
  `topic_pin` varchar(10) NOT NULL DEFAULT 'leave',
  `topic_move` smallint(5) NOT NULL DEFAULT '0',
  `topic_move_link` tinyint(1) NOT NULL DEFAULT '0',
  `topic_title_st` varchar(250) NOT NULL DEFAULT '',
  `topic_title_end` varchar(250) NOT NULL DEFAULT '',
  `topic_reply` tinyint(1) NOT NULL DEFAULT '0',
  `topic_reply_content` text NOT NULL,
  `topic_reply_postcount` tinyint(1) NOT NULL DEFAULT '0',
  `mm_forums` text NOT NULL,
  `topic_approve` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`mm_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_tournaments`
--

CREATE TABLE IF NOT EXISTS `ibf_tournaments` (
  `tid` int(11) NOT NULL AUTO_INCREMENT,
  `gid` int(11) NOT NULL DEFAULT '0',
  `numplayers` int(11) NOT NULL DEFAULT '0',
  `champion` text NOT NULL,
  `datestarted` int(10) NOT NULL DEFAULT '0',
  UNIQUE KEY `tid` (`tid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_tournament_players`
--

CREATE TABLE IF NOT EXISTS `ibf_tournament_players` (
  `mid` int(11) NOT NULL DEFAULT '0',
  `tid` int(11) NOT NULL DEFAULT '0',
  `rung` int(11) NOT NULL DEFAULT '0',
  `rungscore` int(11) NOT NULL DEFAULT '0',
  `faceoff` int(11) NOT NULL DEFAULT '0',
  `timeplayed` int(10) NOT NULL DEFAULT '0',
  `timesplayed` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_tracker`
--

CREATE TABLE IF NOT EXISTS `ibf_tracker` (
  `trid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `member_id` mediumint(8) NOT NULL DEFAULT '0',
  `topic_id` int(10) NOT NULL DEFAULT '0',
  `start_date` int(10) DEFAULT NULL,
  `last_sent` int(10) NOT NULL DEFAULT '0',
  `topic_track_type` varchar(100) NOT NULL DEFAULT 'delayed',
  PRIMARY KEY (`trid`),
  KEY `topic_id` (`topic_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7867 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_tutorials`
--

CREATE TABLE IF NOT EXISTS `ibf_tutorials` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL DEFAULT '0',
  `status` enum('pending','aproved') NOT NULL DEFAULT 'pending',
  `title` varchar(128) NOT NULL DEFAULT '',
  `author_name` varchar(32) NOT NULL DEFAULT '',
  `tutorial` mediumtext NOT NULL,
  `num_votes` tinyint(4) NOT NULL DEFAULT '0',
  `total_votes` bigint(10) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `views` bigint(10) NOT NULL DEFAULT '0',
  `rate` float NOT NULL DEFAULT '0',
  `n_comments` smallint(3) NOT NULL DEFAULT '0',
  `author_id` mediumint(8) NOT NULL DEFAULT '0',
  `tut_source` varchar(128) NOT NULL DEFAULT '',
  `tut_desc` mediumtext NOT NULL,
  `tut_tid` mediumint(4) NOT NULL DEFAULT '0',
  `tut_pid` mediumint(4) NOT NULL DEFAULT '0',
  `link_tut` varchar(128) NOT NULL DEFAULT '',
  `link_top` varchar(128) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=137 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_tutorialsv2`
--

CREATE TABLE IF NOT EXISTS `ibf_tutorialsv2` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `title` varchar(64) NOT NULL DEFAULT '?????',
  `author` varchar(50) NOT NULL DEFAULT '?????',
  `category` varchar(32) NOT NULL DEFAULT '',
  `skill_level` tinyint(1) NOT NULL DEFAULT '0',
  `views` int(4) NOT NULL DEFAULT '0',
  `dated` varchar(32) NOT NULL DEFAULT '',
  `text` text NOT NULL,
  `files` varchar(32) DEFAULT NULL,
  `topics` varchar(32) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `submit_id` mediumint(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  FULLTEXT KEY `text` (`text`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=423 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_tutorialsv2_cats`
--

CREATE TABLE IF NOT EXISTS `ibf_tutorialsv2_cats` (
  `sqlname` varchar(32) NOT NULL DEFAULT '',
  `realname` varchar(32) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_tut_comments`
--

CREATE TABLE IF NOT EXISTS `ibf_tut_comments` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `tid` int(4) NOT NULL DEFAULT '0',
  `owner` varchar(25) NOT NULL DEFAULT '',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `COMMENT` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_tut_config`
--

CREATE TABLE IF NOT EXISTS `ibf_tut_config` (
  `ubbc` int(1) NOT NULL DEFAULT '0',
  `guests` smallint(1) NOT NULL DEFAULT '0',
  `sub` smallint(1) NOT NULL DEFAULT '0',
  `uplo` smallint(1) NOT NULL DEFAULT '0',
  `uplo_perms` varchar(128) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_tut_rel_links`
--

CREATE TABLE IF NOT EXISTS `ibf_tut_rel_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tid` int(4) NOT NULL DEFAULT '0',
  `link` text NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_tut_sections`
--

CREATE TABLE IF NOT EXISTS `ibf_tut_sections` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_upgrade_history`
--

CREATE TABLE IF NOT EXISTS `ibf_upgrade_history` (
  `upgrade_id` int(10) NOT NULL AUTO_INCREMENT,
  `upgrade_version_id` int(10) NOT NULL DEFAULT '0',
  `upgrade_version_human` varchar(200) NOT NULL DEFAULT '',
  `upgrade_date` int(10) NOT NULL DEFAULT '0',
  `upgrade_mid` int(10) NOT NULL DEFAULT '0',
  `upgrade_notes` text NOT NULL,
  PRIMARY KEY (`upgrade_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_validating`
--

CREATE TABLE IF NOT EXISTS `ibf_validating` (
  `vid` varchar(32) NOT NULL DEFAULT '',
  `member_id` mediumint(8) NOT NULL DEFAULT '0',
  `real_group` smallint(3) NOT NULL DEFAULT '0',
  `temp_group` smallint(3) NOT NULL DEFAULT '0',
  `entry_date` int(10) NOT NULL DEFAULT '0',
  `coppa_user` tinyint(1) NOT NULL DEFAULT '0',
  `lost_pass` tinyint(1) NOT NULL DEFAULT '0',
  `new_reg` tinyint(1) NOT NULL DEFAULT '0',
  `email_chg` tinyint(1) NOT NULL DEFAULT '0',
  `ip_address` varchar(16) NOT NULL DEFAULT '0',
  PRIMARY KEY (`vid`),
  KEY `new_reg` (`new_reg`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_voters`
--

CREATE TABLE IF NOT EXISTS `ibf_voters` (
  `vid` int(10) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(16) NOT NULL DEFAULT '',
  `vote_date` int(10) NOT NULL DEFAULT '0',
  `tid` int(10) NOT NULL DEFAULT '0',
  `member_id` varchar(32) DEFAULT NULL,
  `forum_id` smallint(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`vid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=49693 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_warn_decay`
--

CREATE TABLE IF NOT EXISTS `ibf_warn_decay` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `userid` mediumint(8) NOT NULL DEFAULT '0',
  `time2decay` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=91 ;

-- --------------------------------------------------------

--
-- Table structure for table `ibf_warn_logs`
--

CREATE TABLE IF NOT EXISTS `ibf_warn_logs` (
  `wlog_id` int(10) NOT NULL AUTO_INCREMENT,
  `wlog_mid` mediumint(8) NOT NULL DEFAULT '0',
  `wlog_notes` text NOT NULL,
  `wlog_contact` varchar(250) NOT NULL DEFAULT 'none',
  `wlog_contact_content` text NOT NULL,
  `wlog_date` int(10) NOT NULL DEFAULT '0',
  `wlog_type` varchar(6) NOT NULL DEFAULT 'pos',
  `wlog_addedby` mediumint(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`wlog_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2198 ;

-- --------------------------------------------------------

--
-- Table structure for table `iso47s3n_new`
--

CREATE TABLE IF NOT EXISTS `iso47s3n_new` (
  `id` smallint(5) NOT NULL DEFAULT '0',
  `topics` mediumint(6) DEFAULT '0',
  `posts` mediumint(6) DEFAULT '0',
  `last_post` int(10) DEFAULT NULL,
  `last_poster_id` mediumint(8) NOT NULL DEFAULT '0',
  `last_poster_name` varchar(32) DEFAULT NULL,
  `name` varchar(128) NOT NULL DEFAULT '',
  `description` text,
  `position` tinyint(2) DEFAULT NULL,
  `use_ibc` tinyint(1) DEFAULT NULL,
  `use_html` tinyint(1) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `last_title` varchar(128) DEFAULT NULL,
  `last_id` int(10) DEFAULT NULL,
  `sort_key` varchar(32) DEFAULT NULL,
  `sort_order` varchar(32) DEFAULT NULL,
  `prune` tinyint(3) DEFAULT NULL,
  `show_rules` tinyint(1) DEFAULT NULL,
  `preview_posts` tinyint(1) DEFAULT NULL,
  `allow_poll` tinyint(1) NOT NULL DEFAULT '1',
  `allow_pollbump` tinyint(1) NOT NULL DEFAULT '0',
  `inc_postcount` tinyint(1) NOT NULL DEFAULT '1',
  `skin_id` int(10) DEFAULT NULL,
  `parent_id` mediumint(5) DEFAULT '-1',
  `sub_can_post` tinyint(1) DEFAULT '1',
  `quick_reply` tinyint(1) DEFAULT '0',
  `redirect_url` varchar(250) DEFAULT '',
  `redirect_on` tinyint(1) NOT NULL DEFAULT '0',
  `redirect_hits` int(10) NOT NULL DEFAULT '0',
  `redirect_loc` varchar(250) DEFAULT '',
  `rules_title` varchar(255) NOT NULL DEFAULT '',
  `rules_text` text NOT NULL,
  `topic_mm_id` varchar(250) NOT NULL DEFAULT '',
  `notify_modq_emails` text,
  `permission_custom_error` text NOT NULL,
  `permission_array` mediumtext NOT NULL,
  `permission_showtopic` tinyint(1) NOT NULL DEFAULT '0',
  `queued_topics` mediumint(6) NOT NULL DEFAULT '0',
  `queued_posts` mediumint(6) NOT NULL DEFAULT '0',
  `icon` text NOT NULL,
  `start` text,
  `activity` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `position` (`position`,`parent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `s2s_news`
--

CREATE TABLE IF NOT EXISTS `s2s_news` (
  `s2s_id` mediumint(8) NOT NULL DEFAULT '0',
  `s2s_hash` varchar(32) NOT NULL DEFAULT '',
  `s2s_date` bigint(16) NOT NULL DEFAULT '0',
  `s2s_site` varchar(128) NOT NULL DEFAULT '',
  `s2s_athour` varchar(64) NOT NULL DEFAULT '',
  `s2s_short_desc` varchar(128) NOT NULL DEFAULT '',
  `s2s_long_desc` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `spelling_words`
--

CREATE TABLE IF NOT EXISTS `spelling_words` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `word` varchar(30) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT '',
  `sound` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `word` (`word`),
  KEY `sound` (`sound`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=192935 ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
